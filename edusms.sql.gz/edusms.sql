-- Adminer 4.8.1 MySQL 11.2.2-MariaDB-1:11.2.2+maria~ubu2204-log dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `absent_notification_time_setups`;
CREATE TABLE `absent_notification_time_setups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `time_from` varchar(191) DEFAULT NULL,
  `time_to` varchar(191) DEFAULT NULL,
  `active_status` int(11) NOT NULL DEFAULT 1,
  `school_id` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `chat_block_users`;
CREATE TABLE `chat_block_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `block_by` bigint(20) unsigned NOT NULL,
  `block_to` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `chat_conversations`;
CREATE TABLE `chat_conversations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `from_id` bigint(20) unsigned DEFAULT NULL,
  `to_id` bigint(20) unsigned DEFAULT NULL,
  `message` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0 for unread,1 for seen',
  `message_type` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0- text message, 1- image, 2- pdf, 3- doc, 4- voice',
  `file_name` text DEFAULT NULL,
  `original_file_name` text DEFAULT NULL,
  `initial` tinyint(1) NOT NULL DEFAULT 0,
  `reply` bigint(20) unsigned DEFAULT NULL,
  `forward` bigint(20) unsigned DEFAULT NULL,
  `deleted_by_to` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `chat_groups`;
CREATE TABLE `chat_groups` (
  `id` char(36) NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `photo_url` varchar(191) DEFAULT NULL,
  `privacy` int(11) DEFAULT NULL,
  `read_only` tinyint(1) NOT NULL DEFAULT 0,
  `group_type` int(11) NOT NULL DEFAULT 1 COMMENT '1 => Open (Anyone can send message), 2 => Close (Only Admin can send message) ',
  `created_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `chat_group_message_recipients`;
CREATE TABLE `chat_group_message_recipients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `conversation_id` bigint(20) unsigned NOT NULL,
  `group_id` varchar(191) NOT NULL,
  `read_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `chat_group_message_removes`;
CREATE TABLE `chat_group_message_removes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_message_recipient_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `chat_group_users`;
CREATE TABLE `chat_group_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` char(36) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `role` int(11) NOT NULL DEFAULT 1,
  `added_by` bigint(20) unsigned NOT NULL,
  `removed_by` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `chat_invitations`;
CREATE TABLE `chat_invitations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `from` int(10) unsigned NOT NULL,
  `to` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0- pending, 1- connected, 2- blocked',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `chat_invitation_types`;
CREATE TABLE `chat_invitation_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invitation_id` bigint(20) unsigned NOT NULL,
  `type` enum('one-to-one','group','class-teacher') NOT NULL DEFAULT 'one-to-one',
  `section_id` bigint(20) unsigned DEFAULT NULL,
  `class_teacher_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `chat_statuses`;
CREATE TABLE `chat_statuses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0- inactive, 1- active, 2- away, 3- busy',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `check_classes`;
CREATE TABLE `check_classes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `continents`;
CREATE TABLE `continents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `continents_school_id_foreign` (`school_id`),
  CONSTRAINT `continents_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `continets`;
CREATE TABLE `continets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `continets_school_id_foreign` (`school_id`),
  CONSTRAINT `continets_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `native` varchar(191) NOT NULL,
  `phone` varchar(191) NOT NULL,
  `continent` varchar(191) NOT NULL,
  `capital` varchar(191) NOT NULL,
  `currency` varchar(191) NOT NULL,
  `languages` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `countries_school_id_foreign` (`school_id`),
  KEY `countries_academic_id_foreign` (`academic_id`),
  CONSTRAINT `countries_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `countries_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `custom_result_settings`;
CREATE TABLE `custom_result_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `exam_type_id` int(11) NOT NULL,
  `exam_percentage` double(8,2) NOT NULL,
  `merit_list_setting` varchar(191) NOT NULL,
  `academic_year` int(11) NOT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_result_settings_school_id_foreign` (`school_id`),
  KEY `custom_result_settings_academic_id_foreign` (`academic_id`),
  CONSTRAINT `custom_result_settings_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `custom_result_settings_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `fees_invoice_settings`;
CREATE TABLE `fees_invoice_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `per_th` int(11) NOT NULL DEFAULT 2,
  `invoice_type` varchar(191) NOT NULL DEFAULT 'invoice',
  `student_name` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `student_section` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `student_class` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `student_roll` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `student_group` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `student_admission_no` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `footer_1` varchar(255) DEFAULT 'Parent/Student',
  `footer_2` varchar(255) NOT NULL DEFAULT 'Casier',
  `footer_3` varchar(255) NOT NULL DEFAULT 'Officer',
  `signature_p` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `signature_c` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `signature_o` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `c_signature_p` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `c_signature_c` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0=No, 1=Yes',
  `c_signature_o` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `copy_s` varchar(255) DEFAULT 'Parent/Student',
  `copy_o` varchar(255) NOT NULL DEFAULT 'Office',
  `copy_c` varchar(255) NOT NULL DEFAULT 'Casier',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `copy_write_msg` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `fees_invoice_settings_created_by_foreign` (`created_by`),
  KEY `fees_invoice_settings_updated_by_foreign` (`updated_by`),
  KEY `fees_invoice_settings_school_id_foreign` (`school_id`),
  KEY `fees_invoice_settings_academic_id_foreign` (`academic_id`),
  CONSTRAINT `fees_invoice_settings_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fees_invoice_settings_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fees_invoice_settings_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fees_invoice_settings_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `fm_fees_groups`;
CREATE TABLE `fm_fees_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `fm_fees_invoices`;
CREATE TABLE `fm_fees_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` varchar(191) NOT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `create_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `payment_status` varchar(191) DEFAULT NULL,
  `payment_method` varchar(191) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `type` varchar(191) DEFAULT 'fees' COMMENT 'fees, lms',
  `school_id` int(11) DEFAULT NULL,
  `academic_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `record_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fm_fees_invoices_student_id_foreign` (`student_id`),
  CONSTRAINT `fm_fees_invoices_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `fm_fees_invoice_chields`;
CREATE TABLE `fm_fees_invoice_chields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fees_invoice_id` bigint(20) unsigned DEFAULT NULL,
  `fees_type` int(11) DEFAULT NULL,
  `amount` double(8,2) DEFAULT NULL,
  `weaver` double(8,2) DEFAULT NULL,
  `fine` double(8,2) DEFAULT NULL,
  `sub_total` double(8,2) DEFAULT NULL,
  `paid_amount` double(8,2) DEFAULT NULL,
  `due_amount` double(8,2) DEFAULT NULL,
  `note` varchar(191) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `academic_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fm_fees_invoice_chields_fees_invoice_id_foreign` (`fees_invoice_id`),
  CONSTRAINT `fm_fees_invoice_chields_fees_invoice_id_foreign` FOREIGN KEY (`fees_invoice_id`) REFERENCES `fm_fees_invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `fm_fees_invoice_settings`;
CREATE TABLE `fm_fees_invoice_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_positions` text DEFAULT NULL,
  `uniq_id_start` varchar(191) DEFAULT NULL,
  `prefix` varchar(191) DEFAULT NULL,
  `class_limit` int(11) DEFAULT NULL,
  `section_limit` int(11) DEFAULT NULL,
  `admission_limit` int(11) DEFAULT NULL,
  `weaver` varchar(191) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `fm_fees_transactions`;
CREATE TABLE `fm_fees_transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(191) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `payment_method` varchar(191) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `add_wallet_money` double(8,2) DEFAULT NULL,
  `payment_note` varchar(191) DEFAULT NULL,
  `file` text DEFAULT NULL,
  `paid_status` varchar(191) DEFAULT NULL,
  `fees_invoice_id` bigint(20) unsigned DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `academic_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `record_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fm_fees_transactions_fees_invoice_id_foreign` (`fees_invoice_id`),
  CONSTRAINT `fm_fees_transactions_fees_invoice_id_foreign` FOREIGN KEY (`fees_invoice_id`) REFERENCES `fm_fees_invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `fm_fees_transaction_chields`;
CREATE TABLE `fm_fees_transaction_chields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fees_type` varchar(191) DEFAULT NULL,
  `paid_amount` double(8,2) DEFAULT NULL,
  `fine` double(8,2) DEFAULT NULL,
  `weaver` double(8,2) DEFAULT NULL,
  `note` varchar(191) DEFAULT NULL,
  `fees_transaction_id` bigint(20) unsigned DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `academic_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fm_fees_transaction_chields_fees_transaction_id_foreign` (`fees_transaction_id`),
  CONSTRAINT `fm_fees_transaction_chields_fees_transaction_id_foreign` FOREIGN KEY (`fees_transaction_id`) REFERENCES `fm_fees_transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `fm_fees_types`;
CREATE TABLE `fm_fees_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(230) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `fees_group_id` int(10) unsigned DEFAULT 1,
  `type` varchar(191) DEFAULT 'fees' COMMENT 'fees, lms',
  `course_id` int(11) DEFAULT NULL COMMENT 'Only For Lms',
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `fm_fees_weavers`;
CREATE TABLE `fm_fees_weavers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fees_invoice_id` bigint(20) unsigned DEFAULT NULL,
  `fees_type` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `weaver` double(8,2) DEFAULT NULL,
  `note` varchar(191) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `academic_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fm_fees_weavers_fees_invoice_id_foreign` (`fees_invoice_id`),
  CONSTRAINT `fm_fees_weavers_fees_invoice_id_foreign` FOREIGN KEY (`fees_invoice_id`) REFERENCES `fm_fees_invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `infix_module_infos`;
CREATE TABLE `infix_module_infos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT 0,
  `name` varchar(191) DEFAULT NULL,
  `is_saas` tinyint(4) NOT NULL DEFAULT 0,
  `route` varchar(191) DEFAULT NULL,
  `lang_name` varchar(191) DEFAULT NULL,
  `icon_class` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT NULL,
  `type` int(11) DEFAULT NULL COMMENT '1 for module, 2 for module link, 3 for module links crud',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `infix_module_infos_created_by_foreign` (`created_by`),
  KEY `infix_module_infos_updated_by_foreign` (`updated_by`),
  KEY `infix_module_infos_school_id_foreign` (`school_id`),
  CONSTRAINT `infix_module_infos_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `infix_module_infos_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `infix_module_infos_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `infix_module_managers`;
CREATE TABLE `infix_module_managers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `version` varchar(200) DEFAULT NULL,
  `update_url` varchar(200) DEFAULT NULL,
  `purchase_code` varchar(200) DEFAULT NULL,
  `checksum` varchar(200) DEFAULT NULL,
  `installed_domain` varchar(200) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `addon_url` varchar(191) DEFAULT NULL,
  `activated_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `infix_module_student_parent_infos`;
CREATE TABLE `infix_module_student_parent_infos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT 0,
  `name` varchar(191) DEFAULT NULL,
  `route` varchar(191) DEFAULT NULL COMMENT 'url',
  `lang_name` varchar(191) DEFAULT NULL,
  `icon_class` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `type` int(11) DEFAULT NULL COMMENT '1 for module, 2 for module link, 3 for module options',
  `user_type` int(11) DEFAULT NULL COMMENT '1 for student, 2 for parent',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `infix_module_student_parent_infos_created_by_foreign` (`created_by`),
  KEY `infix_module_student_parent_infos_updated_by_foreign` (`updated_by`),
  KEY `infix_module_student_parent_infos_school_id_foreign` (`school_id`),
  CONSTRAINT `infix_module_student_parent_infos_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `infix_module_student_parent_infos_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `infix_module_student_parent_infos_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `infix_permission_assigns`;
CREATE TABLE `infix_permission_assigns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL COMMENT ' module id, module link id, module link options id',
  `module_info` varchar(191) DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `saas_schools` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `infix_permission_assigns_role_id_foreign` (`role_id`),
  KEY `infix_permission_assigns_school_id_foreign` (`school_id`),
  CONSTRAINT `infix_permission_assigns_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `infix_roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `infix_permission_assigns_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `infix_roles`;
CREATE TABLE `infix_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `type` varchar(191) NOT NULL DEFAULT 'System',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` varchar(191) DEFAULT '1',
  `updated_by` varchar(191) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `is_saas` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `infix_roles_school_id_foreign` (`school_id`),
  CONSTRAINT `infix_roles_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `invoice_settings`;
CREATE TABLE `invoice_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `per_th` int(11) NOT NULL DEFAULT 2,
  `prefix` varchar(191) DEFAULT NULL,
  `student_name` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `student_section` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `student_class` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `student_roll` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `student_group` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `student_admission_no` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `footer_1` varchar(255) DEFAULT 'Parent/Student',
  `footer_2` varchar(255) NOT NULL DEFAULT 'Casier',
  `footer_3` varchar(255) NOT NULL DEFAULT 'Officer',
  `signature_p` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `signature_c` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `signature_o` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `c_signature_p` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `c_signature_c` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0=No, 1=Yes',
  `c_signature_o` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=No, 1=Yes',
  `copy_s` varchar(255) DEFAULT 'Parent/Student',
  `copy_o` varchar(255) NOT NULL DEFAULT 'Office',
  `copy_c` varchar(255) NOT NULL DEFAULT 'Casier',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `copy_write_msg` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `invoice_settings_created_by_foreign` (`created_by`),
  KEY `invoice_settings_updated_by_foreign` (`updated_by`),
  KEY `invoice_settings_school_id_foreign` (`school_id`),
  KEY `invoice_settings_academic_id_foreign` (`academic_id`),
  CONSTRAINT `invoice_settings_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoice_settings_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoice_settings_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoice_settings_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `native` varchar(191) NOT NULL,
  `rtl` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `languages_school_id_foreign` (`school_id`),
  CONSTRAINT `languages_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `lesson_planners`;
CREATE TABLE `lesson_planners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `day` int(11) DEFAULT NULL COMMENT '1=sat,2=sun,7=fri',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `lesson_id` int(11) DEFAULT NULL,
  `topic_id` int(11) DEFAULT NULL,
  `lesson_detail_id` int(11) NOT NULL,
  `topic_detail_id` int(11) NOT NULL,
  `sub_topic` varchar(191) DEFAULT NULL,
  `lecture_youube_link` text DEFAULT NULL,
  `lecture_vedio` text DEFAULT NULL,
  `attachment` text DEFAULT NULL,
  `teaching_method` text DEFAULT NULL,
  `general_objectives` text DEFAULT NULL,
  `previous_knowlege` text DEFAULT NULL,
  `comp_question` text DEFAULT NULL,
  `zoom_setup` text DEFAULT NULL,
  `presentation` text DEFAULT NULL,
  `note` text DEFAULT NULL,
  `lesson_date` date NOT NULL,
  `competed_date` date DEFAULT NULL,
  `completed_status` varchar(191) DEFAULT NULL,
  `room_id` int(10) unsigned DEFAULT NULL,
  `teacher_id` int(10) unsigned DEFAULT NULL,
  `class_period_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `routine_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `lesson_planners_room_id_foreign` (`room_id`),
  KEY `lesson_planners_teacher_id_foreign` (`teacher_id`),
  KEY `lesson_planners_class_period_id_foreign` (`class_period_id`),
  KEY `lesson_planners_subject_id_foreign` (`subject_id`),
  KEY `lesson_planners_class_id_foreign` (`class_id`),
  KEY `lesson_planners_section_id_foreign` (`section_id`),
  KEY `lesson_planners_school_id_foreign` (`school_id`),
  KEY `lesson_planners_academic_id_foreign` (`academic_id`),
  CONSTRAINT `lesson_planners_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lesson_planners_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lesson_planners_class_period_id_foreign` FOREIGN KEY (`class_period_id`) REFERENCES `sm_class_times` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lesson_planners_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `sm_class_rooms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lesson_planners_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lesson_planners_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lesson_planners_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lesson_planners_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `sm_staffs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `lesson_plan_topics`;
CREATE TABLE `lesson_plan_topics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sub_topic_title` varchar(191) NOT NULL,
  `topic_id` int(10) unsigned DEFAULT NULL,
  `lesson_planner_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lesson_plan_topics_topic_id_foreign` (`topic_id`),
  KEY `lesson_plan_topics_lesson_planner_id_foreign` (`lesson_planner_id`),
  CONSTRAINT `lesson_plan_topics_lesson_planner_id_foreign` FOREIGN KEY (`lesson_planner_id`) REFERENCES `lesson_planners` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lesson_plan_topics_topic_id_foreign` FOREIGN KEY (`topic_id`) REFERENCES `sm_lesson_topic_details` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `library_subjects`;
CREATE TABLE `library_subjects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(255) NOT NULL,
  `sb_category_id` varchar(255) DEFAULT NULL,
  `subject_code` varchar(255) DEFAULT NULL,
  `subject_type` varchar(191) NOT NULL DEFAULT 'T',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `library_subjects_school_id_foreign` (`school_id`),
  KEY `library_subjects_academic_id_foreign` (`academic_id`),
  CONSTRAINT `library_subjects_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `library_subjects_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `menu_manages`;
CREATE TABLE `menu_manages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT 0,
  `parent_position_no` int(11) DEFAULT 0,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `child_id` int(11) DEFAULT 0,
  `child_position_no` int(11) DEFAULT 0,
  `child_active_status` tinyint(4) NOT NULL DEFAULT 1,
  `role_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_manages_role_id_foreign` (`role_id`),
  KEY `menu_manages_user_id_foreign` (`user_id`),
  KEY `menu_manages_school_id_foreign` (`school_id`),
  KEY `menu_manages_academic_id_foreign` (`academic_id`),
  CONSTRAINT `menu_manages_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE SET NULL,
  CONSTRAINT `menu_manages_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `infix_roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `menu_manages_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `menu_manages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(191) NOT NULL,
  `notifiable_type` varchar(191) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `oauth_access_tokens`;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(191) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `scopes` varchar(100) DEFAULT NULL,
  `revoked` varchar(100) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `oauth_auth_codes`;
CREATE TABLE `oauth_auth_codes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `oauth_clients`;
CREATE TABLE `oauth_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `provider` varchar(191) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `secret` varchar(200) NOT NULL,
  `redirect` text NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `oauth_personal_access_clients`;
CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_personal_access_clients_client_id_index` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `oauth_refresh_tokens`;
CREATE TABLE `oauth_refresh_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `access_token_id` bigint(20) DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `online_exam_student_answer_markings`;
CREATE TABLE `online_exam_student_answer_markings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `online_exam_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `user_answer` varchar(191) DEFAULT NULL,
  `answer_status` varchar(191) DEFAULT NULL,
  `obtain_marks` int(11) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `marked_by` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(100) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `type` varchar(191) NOT NULL DEFAULT 'System',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` varchar(191) DEFAULT '1',
  `updated_by` varchar(191) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `roles_school_id_foreign` (`school_id`),
  CONSTRAINT `roles_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `school_modules`;
CREATE TABLE `school_modules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `module_name` varchar(191) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `school_id` int(10) unsigned NOT NULL DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `school_modules_school_id_foreign` (`school_id`),
  KEY `school_modules_academic_id_foreign` (`academic_id`),
  CONSTRAINT `school_modules_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `school_modules_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sidebars`;
CREATE TABLE `sidebars` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT 0,
  `child_id` int(11) DEFAULT 0,
  `lan_name` varchar(50) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `icon_class` varchar(191) DEFAULT NULL,
  `is_saas` tinyint(4) NOT NULL DEFAULT 0,
  `route` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `infix_module_id` int(10) unsigned DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sidebars_role_id_foreign` (`role_id`),
  KEY `sidebars_user_id_foreign` (`user_id`),
  KEY `sidebars_school_id_foreign` (`school_id`),
  CONSTRAINT `sidebars_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `infix_roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sidebars_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sidebars_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sidebar_news`;
CREATE TABLE `sidebar_news` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(11) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `parent_id` int(11) DEFAULT 0,
  `parent_position_no` int(11) DEFAULT 0,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `child_id` int(11) DEFAULT 0,
  `child_position_no` int(11) DEFAULT 0,
  `child_active_status` tinyint(4) NOT NULL DEFAULT 1,
  `route` varchar(191) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `infix_module_id` int(11) DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sms_templates`;
CREATE TABLE `sms_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) NOT NULL COMMENT 'email, sms',
  `purpose` text NOT NULL,
  `subject` text NOT NULL,
  `body` longtext NOT NULL,
  `module` varchar(191) NOT NULL,
  `variable` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT 'Enable & Disable',
  `school_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sms_templates_school_id_foreign` (`school_id`),
  CONSTRAINT `sms_templates_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_about_pages`;
CREATE TABLE `sm_about_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `main_title` varchar(191) DEFAULT NULL,
  `main_description` text DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `main_image` varchar(191) DEFAULT NULL,
  `button_text` varchar(191) DEFAULT NULL,
  `button_url` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_about_pages_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_about_pages_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_academic_years`;
CREATE TABLE `sm_academic_years` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `year` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `starting_date` date NOT NULL,
  `ending_date` date NOT NULL,
  `copy_with_academic_year` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` varchar(191) DEFAULT NULL,
  `updated_at` varchar(191) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_academic_years_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_academic_years_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_add_expenses`;
CREATE TABLE `sm_add_expenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `amount` double(10,2) DEFAULT NULL,
  `file` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `item_receive_id` int(11) DEFAULT NULL,
  `inventory_id` int(11) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expense_head_id` int(10) unsigned DEFAULT NULL,
  `account_id` int(10) unsigned DEFAULT NULL,
  `payment_method_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_add_expenses_school_id_foreign` (`school_id`),
  KEY `sm_add_expenses_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_add_expenses_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_add_expenses_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_add_incomes`;
CREATE TABLE `sm_add_incomes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `amount` double(10,2) DEFAULT NULL,
  `file` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `item_sell_id` int(11) DEFAULT NULL,
  `fees_collection_id` int(11) DEFAULT NULL,
  `inventory_id` int(11) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `income_head_id` int(10) unsigned DEFAULT NULL,
  `account_id` int(10) unsigned DEFAULT NULL,
  `payment_method_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_add_incomes_account_id_foreign` (`account_id`),
  KEY `sm_add_incomes_payment_method_id_foreign` (`payment_method_id`),
  KEY `sm_add_incomes_school_id_foreign` (`school_id`),
  KEY `sm_add_incomes_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_add_incomes_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_add_incomes_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `sm_bank_accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_add_incomes_payment_method_id_foreign` FOREIGN KEY (`payment_method_id`) REFERENCES `sm_payment_methhods` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_add_incomes_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_add_ons`;
CREATE TABLE `sm_add_ons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_admission_queries`;
CREATE TABLE `sm_admission_queries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `date` date DEFAULT NULL,
  `follow_up_date` date DEFAULT NULL,
  `next_follow_up_date` date DEFAULT NULL,
  `assigned` varchar(191) DEFAULT NULL,
  `reference` int(11) DEFAULT NULL,
  `source` int(11) DEFAULT NULL,
  `no_of_child` int(11) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `class` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_admission_queries_class_foreign` (`class`),
  KEY `sm_admission_queries_school_id_foreign` (`school_id`),
  KEY `sm_admission_queries_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_admission_queries_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_admission_queries_class_foreign` FOREIGN KEY (`class`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_admission_queries_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_admission_query_followups`;
CREATE TABLE `sm_admission_query_followups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `response` text DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` date DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `admission_query_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_admission_query_followups_admission_query_id_foreign` (`admission_query_id`),
  KEY `sm_admission_query_followups_school_id_foreign` (`school_id`),
  KEY `sm_admission_query_followups_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_admission_query_followups_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_admission_query_followups_admission_query_id_foreign` FOREIGN KEY (`admission_query_id`) REFERENCES `sm_admission_queries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_admission_query_followups_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_amount_transfers`;
CREATE TABLE `sm_amount_transfers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `amount` int(11) DEFAULT NULL,
  `purpose` varchar(191) DEFAULT NULL,
  `from_payment_method` int(11) DEFAULT NULL,
  `from_bank_name` int(11) DEFAULT NULL,
  `to_payment_method` int(11) DEFAULT NULL,
  `to_bank_name` int(11) DEFAULT NULL,
  `transfer_date` date DEFAULT NULL,
  `active_status` tinyint(4) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_amount_transfers_school_id_foreign` (`school_id`),
  KEY `sm_amount_transfers_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_amount_transfers_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_amount_transfers_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_assign_class_teachers`;
CREATE TABLE `sm_assign_class_teachers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_assign_class_teachers_class_id_foreign` (`class_id`),
  KEY `sm_assign_class_teachers_section_id_foreign` (`section_id`),
  KEY `sm_assign_class_teachers_school_id_foreign` (`school_id`),
  KEY `sm_assign_class_teachers_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_assign_class_teachers_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_assign_class_teachers_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_assign_class_teachers_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_assign_class_teachers_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_assign_subjects`;
CREATE TABLE `sm_assign_subjects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `teacher_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_assign_subjects_teacher_id_foreign` (`teacher_id`),
  KEY `sm_assign_subjects_class_id_foreign` (`class_id`),
  KEY `sm_assign_subjects_section_id_foreign` (`section_id`),
  KEY `sm_assign_subjects_subject_id_foreign` (`subject_id`),
  KEY `sm_assign_subjects_school_id_foreign` (`school_id`),
  KEY `sm_assign_subjects_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_assign_subjects_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_assign_subjects_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_assign_subjects_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_assign_subjects_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_assign_subjects_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_assign_subjects_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `sm_staffs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_assign_vehicles`;
CREATE TABLE `sm_assign_vehicles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `vehicle_id` int(10) unsigned DEFAULT NULL,
  `route_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_assign_vehicles_vehicle_id_foreign` (`vehicle_id`),
  KEY `sm_assign_vehicles_route_id_foreign` (`route_id`),
  KEY `sm_assign_vehicles_school_id_foreign` (`school_id`),
  KEY `sm_assign_vehicles_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_assign_vehicles_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_assign_vehicles_route_id_foreign` FOREIGN KEY (`route_id`) REFERENCES `sm_routes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_assign_vehicles_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_assign_vehicles_vehicle_id_foreign` FOREIGN KEY (`vehicle_id`) REFERENCES `sm_vehicles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_background_settings`;
CREATE TABLE `sm_background_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `is_default` int(11) NOT NULL DEFAULT 0,
  `school_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_background_settings_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_background_settings_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_backups`;
CREATE TABLE `sm_backups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) DEFAULT NULL,
  `source_link` varchar(255) DEFAULT NULL,
  `file_type` tinyint(4) DEFAULT NULL COMMENT '0=Database, 1=File, 2=Image',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_backups_school_id_foreign` (`school_id`),
  KEY `sm_backups_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_backups_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_backups_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_bank_accounts`;
CREATE TABLE `sm_bank_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(191) DEFAULT NULL,
  `account_name` varchar(191) DEFAULT NULL,
  `account_number` varchar(191) DEFAULT NULL,
  `account_type` varchar(191) DEFAULT NULL,
  `opening_balance` double NOT NULL DEFAULT 0,
  `current_balance` double NOT NULL DEFAULT 0,
  `note` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_bank_accounts_school_id_foreign` (`school_id`),
  KEY `sm_bank_accounts_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_bank_accounts_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_bank_accounts_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_bank_payment_slips`;
CREATE TABLE `sm_bank_payment_slips` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `amount` double(10,2) DEFAULT NULL,
  `slip` varchar(191) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `approve_status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0 pending, 1 approve',
  `payment_mode` varchar(191) NOT NULL COMMENT 'Bk= bank, Cq=Cheque',
  `reason` text DEFAULT NULL,
  `fees_discount_id` int(10) unsigned DEFAULT NULL,
  `fees_type_id` int(10) unsigned DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `assign_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned NOT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `record_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_bank_payment_slips_fees_discount_id_foreign` (`fees_discount_id`),
  KEY `sm_bank_payment_slips_fees_type_id_foreign` (`fees_type_id`),
  KEY `sm_bank_payment_slips_student_id_foreign` (`student_id`),
  KEY `sm_bank_payment_slips_class_id_foreign` (`class_id`),
  KEY `sm_bank_payment_slips_assign_id_foreign` (`assign_id`),
  KEY `sm_bank_payment_slips_section_id_foreign` (`section_id`),
  KEY `sm_bank_payment_slips_school_id_foreign` (`school_id`),
  KEY `sm_bank_payment_slips_academic_id_foreign` (`academic_id`),
  KEY `sm_bank_payment_slips_record_id_foreign` (`record_id`),
  CONSTRAINT `sm_bank_payment_slips_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_bank_payment_slips_assign_id_foreign` FOREIGN KEY (`assign_id`) REFERENCES `sm_fees_assigns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_bank_payment_slips_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_bank_payment_slips_fees_discount_id_foreign` FOREIGN KEY (`fees_discount_id`) REFERENCES `sm_fees_discounts` (`id`),
  CONSTRAINT `sm_bank_payment_slips_fees_type_id_foreign` FOREIGN KEY (`fees_type_id`) REFERENCES `sm_fees_types` (`id`),
  CONSTRAINT `sm_bank_payment_slips_record_id_foreign` FOREIGN KEY (`record_id`) REFERENCES `student_records` (`id`),
  CONSTRAINT `sm_bank_payment_slips_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`),
  CONSTRAINT `sm_bank_payment_slips_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_bank_payment_slips_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_bank_statements`;
CREATE TABLE `sm_bank_statements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bank_id` int(11) DEFAULT NULL,
  `after_balance` int(11) DEFAULT NULL,
  `amount` double(10,2) DEFAULT NULL,
  `type` varchar(11) DEFAULT NULL COMMENT '1 for Income 0 for Expense',
  `payment_method` int(10) unsigned DEFAULT NULL,
  `details` varchar(500) DEFAULT NULL,
  `item_receive_id` int(11) DEFAULT NULL,
  `item_receive_bank_statement_id` int(11) DEFAULT NULL,
  `item_sell_bank_statement_id` int(11) DEFAULT NULL,
  `item_sell_id` int(11) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_base_groups`;
CREATE TABLE `sm_base_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_base_groups_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_base_groups_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_base_setups`;
CREATE TABLE `sm_base_setups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `base_setup_name` varchar(255) NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `base_group_id` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_base_setups_base_group_id_foreign` (`base_group_id`),
  KEY `sm_base_setups_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_base_setups_base_group_id_foreign` FOREIGN KEY (`base_group_id`) REFERENCES `sm_base_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_base_setups_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_books`;
CREATE TABLE `sm_books` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `book_title` varchar(200) DEFAULT NULL,
  `book_number` varchar(200) DEFAULT NULL,
  `isbn_no` varchar(200) DEFAULT NULL,
  `publisher_name` varchar(200) DEFAULT NULL,
  `author_name` varchar(200) DEFAULT NULL,
  `rack_number` varchar(50) DEFAULT NULL,
  `quantity` int(11) DEFAULT 0,
  `book_price` int(11) DEFAULT NULL,
  `post_date` date DEFAULT NULL,
  `details` varchar(500) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `book_subject_id` int(10) unsigned DEFAULT NULL,
  `book_category_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_books_book_category_id_foreign` (`book_category_id`),
  KEY `sm_books_school_id_foreign` (`school_id`),
  KEY `sm_books_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_books_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_books_book_category_id_foreign` FOREIGN KEY (`book_category_id`) REFERENCES `sm_book_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_books_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_book_categories`;
CREATE TABLE `sm_book_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_book_categories_school_id_foreign` (`school_id`),
  KEY `sm_book_categories_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_book_categories_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_book_categories_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_book_issues`;
CREATE TABLE `sm_book_issues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `quantity` int(11) DEFAULT NULL,
  `given_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `issue_status` varchar(191) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `book_id` int(10) unsigned DEFAULT NULL,
  `member_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_book_issues_book_id_foreign` (`book_id`),
  KEY `sm_book_issues_member_id_foreign` (`member_id`),
  KEY `sm_book_issues_school_id_foreign` (`school_id`),
  KEY `sm_book_issues_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_book_issues_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_book_issues_book_id_foreign` FOREIGN KEY (`book_id`) REFERENCES `sm_books` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_book_issues_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_book_issues_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_chart_of_accounts`;
CREATE TABLE `sm_chart_of_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `head` varchar(200) DEFAULT NULL,
  `type` varchar(1) DEFAULT NULL COMMENT 'E = expense, I = income',
  `active_status` int(11) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_chart_of_accounts_school_id_foreign` (`school_id`),
  KEY `sm_chart_of_accounts_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_chart_of_accounts_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_chart_of_accounts_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_classes`;
CREATE TABLE `sm_classes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_name` varchar(200) NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_classes_school_id_foreign` (`school_id`),
  KEY `sm_classes_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_classes_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_classes_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_class_optional_subject`;
CREATE TABLE `sm_class_optional_subject` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `gpa_above` double(8,2) NOT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_class_optional_subject_school_id_foreign` (`school_id`),
  KEY `sm_class_optional_subject_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_class_optional_subject_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_optional_subject_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_class_rooms`;
CREATE TABLE `sm_class_rooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_no` varchar(50) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_class_rooms_school_id_foreign` (`school_id`),
  KEY `sm_class_rooms_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_class_rooms_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_rooms_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_class_routines`;
CREATE TABLE `sm_class_routines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `monday` varchar(200) DEFAULT NULL,
  `monday_start_from` varchar(200) DEFAULT NULL,
  `monday_end_to` varchar(200) DEFAULT NULL,
  `monday_room_id` int(10) unsigned DEFAULT NULL,
  `tuesday` varchar(200) DEFAULT NULL,
  `tuesday_start_from` varchar(200) DEFAULT NULL,
  `tuesday_end_to` varchar(200) DEFAULT NULL,
  `tuesday_room_id` int(10) unsigned DEFAULT NULL,
  `wednesday` varchar(200) DEFAULT NULL,
  `wednesday_start_from` varchar(200) DEFAULT NULL,
  `wednesday_end_to` varchar(200) DEFAULT NULL,
  `wednesday_room_id` int(10) unsigned DEFAULT NULL,
  `thursday` varchar(200) DEFAULT NULL,
  `thursday_start_from` varchar(200) DEFAULT NULL,
  `thursday_end_to` varchar(200) DEFAULT NULL,
  `thursday_room_id` int(10) unsigned DEFAULT NULL,
  `friday` varchar(200) DEFAULT NULL,
  `friday_start_from` varchar(200) DEFAULT NULL,
  `friday_end_to` varchar(200) DEFAULT NULL,
  `friday_room_id` int(10) unsigned DEFAULT NULL,
  `saturday` varchar(200) DEFAULT NULL,
  `saturday_start_from` varchar(200) DEFAULT NULL,
  `saturday_end_to` varchar(200) DEFAULT NULL,
  `saturday_room_id` int(10) unsigned DEFAULT NULL,
  `sunday` varchar(200) DEFAULT NULL,
  `sunday_start_from` varchar(200) DEFAULT NULL,
  `sunday_end_to` varchar(200) DEFAULT NULL,
  `sunday_room_id` int(10) unsigned DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_class_routines_class_id_foreign` (`class_id`),
  KEY `sm_class_routines_section_id_foreign` (`section_id`),
  KEY `sm_class_routines_subject_id_foreign` (`subject_id`),
  KEY `sm_class_routines_school_id_foreign` (`school_id`),
  KEY `sm_class_routines_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_class_routines_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_routines_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_routines_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_routines_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_routines_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_class_routine_updates`;
CREATE TABLE `sm_class_routine_updates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `day` int(11) DEFAULT NULL COMMENT '1=sat,2=sun,7=fri',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `room_id` int(10) unsigned DEFAULT NULL,
  `teacher_id` int(10) unsigned DEFAULT NULL,
  `class_period_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `is_break` tinyint(4) DEFAULT NULL COMMENT '1 = tiffin time, 0 = class',
  PRIMARY KEY (`id`),
  KEY `sm_class_routine_updates_room_id_foreign` (`room_id`),
  KEY `sm_class_routine_updates_teacher_id_foreign` (`teacher_id`),
  KEY `sm_class_routine_updates_class_period_id_foreign` (`class_period_id`),
  KEY `sm_class_routine_updates_subject_id_foreign` (`subject_id`),
  KEY `sm_class_routine_updates_class_id_foreign` (`class_id`),
  KEY `sm_class_routine_updates_section_id_foreign` (`section_id`),
  KEY `sm_class_routine_updates_school_id_foreign` (`school_id`),
  KEY `sm_class_routine_updates_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_class_routine_updates_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_routine_updates_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_routine_updates_class_period_id_foreign` FOREIGN KEY (`class_period_id`) REFERENCES `sm_class_times` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_routine_updates_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `sm_class_rooms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_routine_updates_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_routine_updates_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_routine_updates_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_routine_updates_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `sm_staffs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_class_sections`;
CREATE TABLE `sm_class_sections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_class_sections_class_id_foreign` (`class_id`),
  KEY `sm_class_sections_section_id_foreign` (`section_id`),
  KEY `sm_class_sections_school_id_foreign` (`school_id`),
  KEY `sm_class_sections_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_class_sections_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_sections_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_sections_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_sections_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_class_teachers`;
CREATE TABLE `sm_class_teachers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `teacher_id` int(10) unsigned DEFAULT NULL,
  `assign_class_teacher_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_class_teachers_teacher_id_foreign` (`teacher_id`),
  KEY `sm_class_teachers_assign_class_teacher_id_foreign` (`assign_class_teacher_id`),
  KEY `sm_class_teachers_school_id_foreign` (`school_id`),
  KEY `sm_class_teachers_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_class_teachers_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_teachers_assign_class_teacher_id_foreign` FOREIGN KEY (`assign_class_teacher_id`) REFERENCES `sm_assign_class_teachers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_teachers_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_teachers_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `sm_staffs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_class_times`;
CREATE TABLE `sm_class_times` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('exam','class') DEFAULT NULL,
  `period` varchar(191) DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `is_break` tinyint(4) DEFAULT NULL COMMENT '1 = tiffin time, 0 = class',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_class_times_school_id_foreign` (`school_id`),
  KEY `sm_class_times_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_class_times_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_class_times_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_complaints`;
CREATE TABLE `sm_complaints` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `complaint_by` varchar(191) DEFAULT NULL,
  `complaint_type` tinyint(4) DEFAULT NULL,
  `complaint_source` tinyint(4) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `action_taken` varchar(191) DEFAULT NULL,
  `assigned` varchar(191) DEFAULT NULL,
  `file` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_complaints_school_id_foreign` (`school_id`),
  KEY `sm_complaints_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_complaints_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_complaints_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_contact_messages`;
CREATE TABLE `sm_contact_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `view_status` tinyint(4) NOT NULL DEFAULT 0,
  `reply_status` tinyint(4) NOT NULL DEFAULT 0,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_contact_messages_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_contact_messages_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_contact_pages`;
CREATE TABLE `sm_contact_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `button_text` varchar(191) DEFAULT NULL,
  `button_url` varchar(191) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `address_text` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `phone_text` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `email_text` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `longitude` varchar(191) DEFAULT NULL,
  `zoom_level` int(11) DEFAULT NULL,
  `google_map_address` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_contact_pages_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_contact_pages_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_content_types`;
CREATE TABLE `sm_content_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_content_types_school_id_foreign` (`school_id`),
  KEY `sm_content_types_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_content_types_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_content_types_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_countries`;
CREATE TABLE `sm_countries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `native` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `continent` varchar(255) DEFAULT NULL,
  `capital` varchar(255) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `languages` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_countries_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_countries_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


DROP TABLE IF EXISTS `sm_courses`;
CREATE TABLE `sm_courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) NOT NULL,
  `image` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `overview` text DEFAULT NULL,
  `outline` text DEFAULT NULL,
  `prerequisites` text DEFAULT NULL,
  `resources` text DEFAULT NULL,
  `stats` text DEFAULT NULL,
  `active_status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_courses_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_courses_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_course_categories`;
CREATE TABLE `sm_course_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(191) DEFAULT NULL,
  `category_image` text DEFAULT NULL,
  `school_id` bigint(20) unsigned NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_course_pages`;
CREATE TABLE `sm_course_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `main_title` varchar(191) DEFAULT NULL,
  `main_description` text DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `main_image` varchar(191) DEFAULT NULL,
  `button_text` varchar(191) DEFAULT NULL,
  `button_url` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `is_parent` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_course_pages_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_course_pages_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_currencies`;
CREATE TABLE `sm_currencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `code` varchar(191) DEFAULT NULL,
  `symbol` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_currencies_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_currencies_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_custom_fields`;
CREATE TABLE `sm_custom_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_name` varchar(191) NOT NULL,
  `label` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL,
  `min_max_length` varchar(191) DEFAULT NULL,
  `min_max_value` varchar(191) DEFAULT NULL,
  `name_value` varchar(191) DEFAULT NULL,
  `width` varchar(191) DEFAULT NULL,
  `required` tinyint(4) DEFAULT NULL,
  `school_id` int(11) DEFAULT 1,
  `academic_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_custom_links`;
CREATE TABLE `sm_custom_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title1` varchar(255) DEFAULT NULL,
  `title2` varchar(255) DEFAULT NULL,
  `title3` varchar(255) DEFAULT NULL,
  `title4` varchar(255) DEFAULT NULL,
  `link_label1` varchar(255) DEFAULT NULL,
  `link_href1` varchar(255) DEFAULT NULL,
  `link_label2` varchar(255) DEFAULT NULL,
  `link_href2` varchar(255) DEFAULT NULL,
  `link_label3` varchar(255) DEFAULT NULL,
  `link_href3` varchar(255) DEFAULT NULL,
  `link_label4` varchar(255) DEFAULT NULL,
  `link_href4` varchar(255) DEFAULT NULL,
  `link_label5` varchar(255) DEFAULT NULL,
  `link_href5` varchar(255) DEFAULT NULL,
  `link_label6` varchar(255) DEFAULT NULL,
  `link_href6` varchar(255) DEFAULT NULL,
  `link_label7` varchar(255) DEFAULT NULL,
  `link_href7` varchar(255) DEFAULT NULL,
  `link_label8` varchar(255) DEFAULT NULL,
  `link_href8` varchar(255) DEFAULT NULL,
  `link_label9` varchar(255) DEFAULT NULL,
  `link_href9` varchar(255) DEFAULT NULL,
  `link_label10` varchar(255) DEFAULT NULL,
  `link_href10` varchar(255) DEFAULT NULL,
  `link_label11` varchar(255) DEFAULT NULL,
  `link_href11` varchar(255) DEFAULT NULL,
  `link_label12` varchar(255) DEFAULT NULL,
  `link_href12` varchar(255) DEFAULT NULL,
  `link_label13` varchar(255) DEFAULT NULL,
  `link_href13` varchar(255) DEFAULT NULL,
  `link_label14` varchar(255) DEFAULT NULL,
  `link_href14` varchar(255) DEFAULT NULL,
  `link_label15` varchar(255) DEFAULT NULL,
  `link_href15` varchar(255) DEFAULT NULL,
  `link_label16` varchar(255) DEFAULT NULL,
  `link_href16` varchar(255) DEFAULT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `dribble_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `behance_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_custom_links_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_custom_links_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_custom_temporary_results`;
CREATE TABLE `sm_custom_temporary_results` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `admission_no` varchar(200) DEFAULT NULL,
  `full_name` varchar(200) DEFAULT NULL,
  `term1` varchar(200) DEFAULT NULL,
  `gpa1` varchar(200) DEFAULT NULL,
  `term2` varchar(200) DEFAULT NULL,
  `gpa2` varchar(200) DEFAULT NULL,
  `term3` varchar(200) DEFAULT NULL,
  `gpa3` varchar(200) DEFAULT NULL,
  `final_result` varchar(200) DEFAULT NULL,
  `final_grade` varchar(200) DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_custom_temporary_results_school_id_foreign` (`school_id`),
  KEY `sm_custom_temporary_results_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_custom_temporary_results_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_custom_temporary_results_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_dashboard_settings`;
CREATE TABLE `sm_dashboard_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dashboard_sec_id` int(11) NOT NULL,
  `active_status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_dashboard_settings_role_id_foreign` (`role_id`),
  KEY `sm_dashboard_settings_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_dashboard_settings_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_dashboard_settings_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_date_formats`;
CREATE TABLE `sm_date_formats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `format` varchar(191) DEFAULT NULL,
  `normal_view` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_date_formats_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_date_formats_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_designations`;
CREATE TABLE `sm_designations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `is_saas` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `sm_designations_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_designations_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_dormitory_lists`;
CREATE TABLE `sm_dormitory_lists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dormitory_name` varchar(200) NOT NULL,
  `type` varchar(191) NOT NULL COMMENT 'B=Boys, G=Girls',
  `address` varchar(191) DEFAULT NULL,
  `intake` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_dormitory_lists_school_id_foreign` (`school_id`),
  KEY `sm_dormitory_lists_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_dormitory_lists_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_dormitory_lists_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_email_settings`;
CREATE TABLE `sm_email_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email_engine_type` varchar(191) DEFAULT NULL,
  `from_name` varchar(191) DEFAULT NULL,
  `from_email` varchar(191) DEFAULT NULL,
  `mail_driver` varchar(191) DEFAULT NULL,
  `mail_host` varchar(191) DEFAULT NULL,
  `mail_port` varchar(191) DEFAULT NULL,
  `mail_username` varchar(191) DEFAULT NULL,
  `mail_password` varchar(191) DEFAULT NULL,
  `mail_encryption` varchar(191) DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_email_settings_school_id_foreign` (`school_id`),
  KEY `sm_email_settings_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_email_settings_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_email_settings_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_email_sms_logs`;
CREATE TABLE `sm_email_sms_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `send_date` date DEFAULT NULL,
  `send_through` varchar(191) DEFAULT NULL,
  `send_to` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_email_sms_logs_school_id_foreign` (`school_id`),
  KEY `sm_email_sms_logs_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_email_sms_logs_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_email_sms_logs_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_events`;
CREATE TABLE `sm_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_title` varchar(200) DEFAULT NULL,
  `for_whom` varchar(200) DEFAULT NULL COMMENT 'teacher, student, parents, all',
  `event_location` varchar(200) DEFAULT NULL,
  `event_des` varchar(500) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `uplad_image_file` varchar(200) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_events_school_id_foreign` (`school_id`),
  KEY `sm_events_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_events_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_events_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_exams`;
CREATE TABLE `sm_exams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `exam_mark` double(8,2) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `exam_type_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_exams_exam_type_id_foreign` (`exam_type_id`),
  KEY `sm_exams_class_id_foreign` (`class_id`),
  KEY `sm_exams_section_id_foreign` (`section_id`),
  KEY `sm_exams_subject_id_foreign` (`subject_id`),
  KEY `sm_exams_school_id_foreign` (`school_id`),
  KEY `sm_exams_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_exams_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exams_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exams_exam_type_id_foreign` FOREIGN KEY (`exam_type_id`) REFERENCES `sm_exam_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exams_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exams_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exams_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_exam_attendances`;
CREATE TABLE `sm_exam_attendances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `exam_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_exam_attendances_subject_id_foreign` (`subject_id`),
  KEY `sm_exam_attendances_exam_id_foreign` (`exam_id`),
  KEY `sm_exam_attendances_class_id_foreign` (`class_id`),
  KEY `sm_exam_attendances_section_id_foreign` (`section_id`),
  KEY `sm_exam_attendances_school_id_foreign` (`school_id`),
  KEY `sm_exam_attendances_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_exam_attendances_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_attendances_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_attendances_exam_id_foreign` FOREIGN KEY (`exam_id`) REFERENCES `sm_exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_attendances_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_attendances_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_attendances_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_exam_attendance_children`;
CREATE TABLE `sm_exam_attendance_children` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attendance_type` varchar(2) DEFAULT NULL COMMENT 'P = present A = Absent',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `exam_attendance_id` int(10) unsigned DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `student_record_id` bigint(20) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_exam_attendance_children_exam_attendance_id_foreign` (`exam_attendance_id`),
  KEY `sm_exam_attendance_children_student_id_foreign` (`student_id`),
  KEY `sm_exam_attendance_children_school_id_foreign` (`school_id`),
  KEY `sm_exam_attendance_children_academic_id_foreign` (`academic_id`),
  KEY `sm_exam_attendance_children_student_record_id_foreign` (`student_record_id`),
  KEY `sm_exam_attendance_children_class_id_foreign` (`class_id`),
  KEY `sm_exam_attendance_children_section_id_foreign` (`section_id`),
  CONSTRAINT `sm_exam_attendance_children_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_attendance_children_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_attendance_children_exam_attendance_id_foreign` FOREIGN KEY (`exam_attendance_id`) REFERENCES `sm_exam_attendances` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_attendance_children_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_attendance_children_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_attendance_children_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_attendance_children_student_record_id_foreign` FOREIGN KEY (`student_record_id`) REFERENCES `student_records` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_exam_marks_registers`;
CREATE TABLE `sm_exam_marks_registers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `obtained_marks` varchar(200) DEFAULT NULL,
  `exam_date` date DEFAULT NULL,
  `comments` varchar(500) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `exam_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_exam_marks_registers_exam_id_foreign` (`exam_id`),
  KEY `sm_exam_marks_registers_student_id_foreign` (`student_id`),
  KEY `sm_exam_marks_registers_subject_id_foreign` (`subject_id`),
  KEY `sm_exam_marks_registers_school_id_foreign` (`school_id`),
  KEY `sm_exam_marks_registers_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_exam_marks_registers_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_marks_registers_exam_id_foreign` FOREIGN KEY (`exam_id`) REFERENCES `sm_exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_marks_registers_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_marks_registers_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_marks_registers_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_exam_schedules`;
CREATE TABLE `sm_exam_schedules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `exam_period_id` int(10) unsigned DEFAULT NULL,
  `room_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `exam_term_id` int(10) unsigned DEFAULT NULL,
  `exam_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `teacher_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_exam_schedules_exam_period_id_foreign` (`exam_period_id`),
  KEY `sm_exam_schedules_room_id_foreign` (`room_id`),
  KEY `sm_exam_schedules_subject_id_foreign` (`subject_id`),
  KEY `sm_exam_schedules_exam_term_id_foreign` (`exam_term_id`),
  KEY `sm_exam_schedules_exam_id_foreign` (`exam_id`),
  KEY `sm_exam_schedules_class_id_foreign` (`class_id`),
  KEY `sm_exam_schedules_section_id_foreign` (`section_id`),
  KEY `sm_exam_schedules_school_id_foreign` (`school_id`),
  KEY `sm_exam_schedules_academic_id_foreign` (`academic_id`),
  KEY `sm_exam_schedules_teacher_id_foreign` (`teacher_id`),
  CONSTRAINT `sm_exam_schedules_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_schedules_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_schedules_exam_id_foreign` FOREIGN KEY (`exam_id`) REFERENCES `sm_exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_schedules_exam_period_id_foreign` FOREIGN KEY (`exam_period_id`) REFERENCES `sm_class_times` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_schedules_exam_term_id_foreign` FOREIGN KEY (`exam_term_id`) REFERENCES `sm_exam_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_schedules_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `sm_room_lists` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_schedules_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_schedules_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_schedules_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_schedules_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `sm_staffs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_exam_schedule_subjects`;
CREATE TABLE `sm_exam_schedule_subjects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `start_time` varchar(200) DEFAULT NULL,
  `end_time` varchar(200) DEFAULT NULL,
  `room` varchar(200) DEFAULT NULL,
  `full_mark` int(11) DEFAULT NULL,
  `pass_mark` int(11) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `exam_schedule_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_exam_schedule_subjects_exam_schedule_id_foreign` (`exam_schedule_id`),
  KEY `sm_exam_schedule_subjects_subject_id_foreign` (`subject_id`),
  KEY `sm_exam_schedule_subjects_school_id_foreign` (`school_id`),
  KEY `sm_exam_schedule_subjects_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_exam_schedule_subjects_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_schedule_subjects_exam_schedule_id_foreign` FOREIGN KEY (`exam_schedule_id`) REFERENCES `sm_exam_schedules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_schedule_subjects_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_schedule_subjects_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_exam_settings`;
CREATE TABLE `sm_exam_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `exam_type` int(11) DEFAULT NULL,
  `title` varchar(191) DEFAULT NULL,
  `publish_date` date DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `file` varchar(200) DEFAULT NULL,
  `active_status` tinyint(4) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_exam_settings_school_id_foreign` (`school_id`),
  KEY `sm_exam_settings_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_exam_settings_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_settings_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_exam_setups`;
CREATE TABLE `sm_exam_setups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `exam_title` varchar(255) DEFAULT NULL,
  `exam_mark` double(8,2) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `exam_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `exam_term_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_exam_setups_exam_id_foreign` (`exam_id`),
  KEY `sm_exam_setups_class_id_foreign` (`class_id`),
  KEY `sm_exam_setups_subject_id_foreign` (`subject_id`),
  KEY `sm_exam_setups_section_id_foreign` (`section_id`),
  KEY `sm_exam_setups_exam_term_id_foreign` (`exam_term_id`),
  KEY `sm_exam_setups_school_id_foreign` (`school_id`),
  KEY `sm_exam_setups_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_exam_setups_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_setups_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_setups_exam_id_foreign` FOREIGN KEY (`exam_id`) REFERENCES `sm_exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_setups_exam_term_id_foreign` FOREIGN KEY (`exam_term_id`) REFERENCES `sm_exam_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_setups_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_setups_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_setups_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_exam_types`;
CREATE TABLE `sm_exam_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` int(11) NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL,
  `percentage` double(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_exam_types_school_id_foreign` (`school_id`),
  KEY `sm_exam_types_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_exam_types_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_exam_types_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_expense_heads`;
CREATE TABLE `sm_expense_heads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_expense_heads_school_id_foreign` (`school_id`),
  KEY `sm_expense_heads_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_expense_heads_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_expense_heads_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_fees_assigns`;
CREATE TABLE `sm_fees_assigns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `fees_amount` double(10,2) DEFAULT NULL,
  `applied_discount` double(10,2) DEFAULT NULL,
  `fees_master_id` int(10) unsigned DEFAULT NULL,
  `fees_discount_id` int(10) unsigned DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `record_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_fees_assigns_fees_master_id_foreign` (`fees_master_id`),
  KEY `sm_fees_assigns_fees_discount_id_foreign` (`fees_discount_id`),
  KEY `sm_fees_assigns_student_id_foreign` (`student_id`),
  KEY `sm_fees_assigns_school_id_foreign` (`school_id`),
  KEY `sm_fees_assigns_academic_id_foreign` (`academic_id`),
  KEY `sm_fees_assigns_record_id_foreign` (`record_id`),
  CONSTRAINT `sm_fees_assigns_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_assigns_fees_discount_id_foreign` FOREIGN KEY (`fees_discount_id`) REFERENCES `sm_fees_discounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_assigns_fees_master_id_foreign` FOREIGN KEY (`fees_master_id`) REFERENCES `sm_fees_masters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_assigns_record_id_foreign` FOREIGN KEY (`record_id`) REFERENCES `student_records` (`id`),
  CONSTRAINT `sm_fees_assigns_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_assigns_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_fees_assign_discounts`;
CREATE TABLE `sm_fees_assign_discounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `fees_discount_id` int(10) unsigned DEFAULT NULL,
  `fees_type_id` int(10) unsigned DEFAULT NULL,
  `fees_group_id` int(10) unsigned DEFAULT NULL,
  `applied_amount` double DEFAULT 0,
  `unapplied_amount` double DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `record_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_fees_assign_discounts_student_id_foreign` (`student_id`),
  KEY `sm_fees_assign_discounts_fees_discount_id_foreign` (`fees_discount_id`),
  KEY `sm_fees_assign_discounts_school_id_foreign` (`school_id`),
  KEY `sm_fees_assign_discounts_academic_id_foreign` (`academic_id`),
  KEY `sm_fees_assign_discounts_record_id_foreign` (`record_id`),
  CONSTRAINT `sm_fees_assign_discounts_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_assign_discounts_fees_discount_id_foreign` FOREIGN KEY (`fees_discount_id`) REFERENCES `sm_fees_discounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_assign_discounts_record_id_foreign` FOREIGN KEY (`record_id`) REFERENCES `student_records` (`id`),
  CONSTRAINT `sm_fees_assign_discounts_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_assign_discounts_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_fees_carry_forwards`;
CREATE TABLE `sm_fees_carry_forwards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `balance` double(16,2) NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `notes` varchar(191) NOT NULL DEFAULT 'Fees Carry Forward',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_fees_carry_forwards_student_id_foreign` (`student_id`),
  KEY `sm_fees_carry_forwards_school_id_foreign` (`school_id`),
  KEY `sm_fees_carry_forwards_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_fees_carry_forwards_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_carry_forwards_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_carry_forwards_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_fees_discounts`;
CREATE TABLE `sm_fees_discounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `code` varchar(200) DEFAULT NULL,
  `type` enum('once','year') DEFAULT NULL COMMENT 'once for one time, year for all months',
  `amount` double(10,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `record_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_fees_discounts_school_id_foreign` (`school_id`),
  KEY `sm_fees_discounts_academic_id_foreign` (`academic_id`),
  KEY `sm_fees_discounts_record_id_foreign` (`record_id`),
  CONSTRAINT `sm_fees_discounts_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_discounts_record_id_foreign` FOREIGN KEY (`record_id`) REFERENCES `student_records` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_discounts_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_fees_groups`;
CREATE TABLE `sm_fees_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `type` varchar(200) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_fees_groups_school_id_foreign` (`school_id`),
  KEY `sm_fees_groups_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_fees_groups_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_groups_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_fees_masters`;
CREATE TABLE `sm_fees_masters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `amount` double(10,2) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `fees_group_id` int(10) unsigned DEFAULT NULL,
  `fees_type_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_fees_masters_fees_group_id_foreign` (`fees_group_id`),
  KEY `sm_fees_masters_fees_type_id_foreign` (`fees_type_id`),
  KEY `sm_fees_masters_school_id_foreign` (`school_id`),
  KEY `sm_fees_masters_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_fees_masters_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_masters_fees_group_id_foreign` FOREIGN KEY (`fees_group_id`) REFERENCES `sm_fees_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_masters_fees_type_id_foreign` FOREIGN KEY (`fees_type_id`) REFERENCES `sm_fees_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_masters_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_fees_payments`;
CREATE TABLE `sm_fees_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `discount_month` tinyint(4) DEFAULT NULL,
  `discount_amount` double(8,2) DEFAULT NULL,
  `fine` double(8,2) DEFAULT NULL,
  `amount` double(10,2) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_mode` varchar(100) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `slip` varchar(191) DEFAULT NULL,
  `fine_title` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `assign_id` int(10) unsigned DEFAULT NULL,
  `bank_id` int(10) unsigned DEFAULT NULL,
  `fees_discount_id` int(10) unsigned DEFAULT NULL,
  `fees_type_id` int(10) unsigned DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `record_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_fees_payments_assign_id_foreign` (`assign_id`),
  KEY `sm_fees_payments_bank_id_foreign` (`bank_id`),
  KEY `sm_fees_payments_fees_discount_id_foreign` (`fees_discount_id`),
  KEY `sm_fees_payments_fees_type_id_foreign` (`fees_type_id`),
  KEY `sm_fees_payments_student_id_foreign` (`student_id`),
  KEY `sm_fees_payments_school_id_foreign` (`school_id`),
  KEY `sm_fees_payments_academic_id_foreign` (`academic_id`),
  KEY `sm_fees_payments_record_id_foreign` (`record_id`),
  CONSTRAINT `sm_fees_payments_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_payments_assign_id_foreign` FOREIGN KEY (`assign_id`) REFERENCES `sm_fees_assigns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_payments_bank_id_foreign` FOREIGN KEY (`bank_id`) REFERENCES `sm_bank_accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_payments_fees_discount_id_foreign` FOREIGN KEY (`fees_discount_id`) REFERENCES `sm_fees_discounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_payments_fees_type_id_foreign` FOREIGN KEY (`fees_type_id`) REFERENCES `sm_fees_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_payments_record_id_foreign` FOREIGN KEY (`record_id`) REFERENCES `student_records` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_payments_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_payments_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_fees_types`;
CREATE TABLE `sm_fees_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(230) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `fees_group_id` int(10) unsigned DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_fees_types_fees_group_id_foreign` (`fees_group_id`),
  KEY `sm_fees_types_school_id_foreign` (`school_id`),
  KEY `sm_fees_types_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_fees_types_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_types_fees_group_id_foreign` FOREIGN KEY (`fees_group_id`) REFERENCES `sm_fees_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_fees_types_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_frontend_persmissions`;
CREATE TABLE `sm_frontend_persmissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `is_published` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_frontend_persmissions_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_frontend_persmissions_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_general_settings`;
CREATE TABLE `sm_general_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_name` varchar(191) DEFAULT NULL,
  `site_title` varchar(191) DEFAULT NULL,
  `school_code` varchar(191) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `file_size` varchar(191) NOT NULL DEFAULT '102400',
  `currency` varchar(191) DEFAULT 'USD',
  `currency_symbol` varchar(191) DEFAULT '$',
  `promotionSetting` int(11) DEFAULT 0,
  `logo` varchar(191) DEFAULT NULL,
  `favicon` varchar(191) DEFAULT NULL,
  `system_version` varchar(191) DEFAULT '6.5.9',
  `active_status` int(11) DEFAULT 1,
  `currency_code` varchar(191) DEFAULT 'USD',
  `language_name` varchar(191) DEFAULT 'en',
  `session_year` varchar(191) DEFAULT '2020',
  `system_purchase_code` varchar(191) DEFAULT NULL,
  `system_activated_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  `envato_user` varchar(191) DEFAULT NULL,
  `envato_item_id` varchar(191) DEFAULT NULL,
  `system_domain` varchar(191) DEFAULT NULL,
  `copyright_text` varchar(191) DEFAULT NULL,
  `api_url` int(11) NOT NULL DEFAULT 1,
  `website_btn` int(11) NOT NULL DEFAULT 1,
  `dashboard_btn` int(11) NOT NULL DEFAULT 1,
  `report_btn` int(11) NOT NULL DEFAULT 1,
  `style_btn` int(11) NOT NULL DEFAULT 1,
  `ltl_rtl_btn` int(11) NOT NULL DEFAULT 1,
  `lang_btn` int(11) NOT NULL DEFAULT 1,
  `website_url` varchar(191) DEFAULT NULL,
  `ttl_rtl` int(11) NOT NULL DEFAULT 2,
  `phone_number_privacy` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `week_start_id` int(11) DEFAULT NULL,
  `time_zone_id` int(11) DEFAULT NULL,
  `attendance_layout` int(11) DEFAULT 1,
  `session_id` int(10) unsigned DEFAULT NULL,
  `language_id` int(10) unsigned DEFAULT 1,
  `date_format_id` int(10) unsigned DEFAULT 1,
  `ss_page_load` int(11) DEFAULT 3,
  `school_id` int(10) unsigned DEFAULT 1,
  `software_version` varchar(100) DEFAULT NULL,
  `email_driver` varchar(191) NOT NULL DEFAULT 'php',
  `fcm_key` text DEFAULT NULL,
  `Lesson` int(11) DEFAULT 1,
  `Chat` int(11) DEFAULT 1,
  `FeesCollection` int(11) DEFAULT 0,
  `income_head_id` int(11) DEFAULT 0,
  `InfixBiometrics` int(11) DEFAULT 0,
  `ResultReports` int(11) DEFAULT 0,
  `TemplateSettings` int(11) DEFAULT 1,
  `MenuManage` int(11) DEFAULT 1,
  `RolePermission` int(11) DEFAULT 1,
  `RazorPay` int(11) DEFAULT 0,
  `Saas` int(11) DEFAULT 1,
  `StudentAbsentNotification` int(11) DEFAULT 1,
  `ParentRegistration` int(11) DEFAULT 0,
  `Zoom` int(11) DEFAULT 0,
  `BBB` int(11) DEFAULT 0,
  `VideoWatch` int(11) DEFAULT 0,
  `Jitsi` int(11) DEFAULT 0,
  `OnlineExam` int(11) DEFAULT 0,
  `SaasSubscription` int(11) DEFAULT 0,
  `SaasRolePermission` int(11) DEFAULT 0,
  `BulkPrint` int(11) DEFAULT 1,
  `HimalayaSms` int(11) DEFAULT 1,
  `XenditPayment` int(11) DEFAULT 1,
  `Wallet` int(11) DEFAULT 1,
  `Lms` int(11) DEFAULT 0,
  `University` int(11) DEFAULT 0,
  `fees_status` int(11) DEFAULT 1,
  `lms_checkout` int(11) DEFAULT 0,
  `academic_id` int(10) unsigned DEFAULT NULL,
  `KhaltiPayment` int(11) DEFAULT 0,
  `AppSlider` int(11) DEFAULT 0,
  `Raudhahpay` int(11) NOT NULL DEFAULT 1,
  `multiple_roll` tinyint(4) DEFAULT 0,
  `sub_topic_enable` tinyint(1) NOT NULL DEFAULT 1,
  `preloader_status` tinyint(1) NOT NULL DEFAULT 1,
  `preloader_style` tinyint(1) NOT NULL DEFAULT 3,
  `preloader_type` tinyint(1) NOT NULL DEFAULT 1,
  `preloader_image` varchar(191) NOT NULL DEFAULT 'public/uploads/settings/preloader/preloader1.gif',
  PRIMARY KEY (`id`),
  KEY `sm_general_settings_session_id_foreign` (`session_id`),
  KEY `sm_general_settings_language_id_foreign` (`language_id`),
  KEY `sm_general_settings_date_format_id_foreign` (`date_format_id`),
  KEY `sm_general_settings_school_id_foreign` (`school_id`),
  KEY `sm_general_settings_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_general_settings_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_general_settings_date_format_id_foreign` FOREIGN KEY (`date_format_id`) REFERENCES `sm_date_formats` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_general_settings_language_id_foreign` FOREIGN KEY (`language_id`) REFERENCES `sm_languages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_general_settings_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_general_settings_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_header_menu_managers`;
CREATE TABLE `sm_header_menu_managers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) NOT NULL,
  `element_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(191) DEFAULT NULL,
  `link` varchar(191) DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  `show` tinyint(1) NOT NULL DEFAULT 0,
  `is_newtab` tinyint(1) NOT NULL DEFAULT 0,
  `school_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_header_menu_managers_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_header_menu_managers_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_holidays`;
CREATE TABLE `sm_holidays` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `holiday_title` varchar(200) DEFAULT NULL,
  `details` varchar(500) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `upload_image_file` varchar(200) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_holidays_school_id_foreign` (`school_id`),
  KEY `sm_holidays_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_holidays_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_holidays_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_homeworks`;
CREATE TABLE `sm_homeworks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `homework_date` date DEFAULT NULL,
  `submission_date` date DEFAULT NULL,
  `evaluation_date` date DEFAULT NULL,
  `file` varchar(200) DEFAULT NULL,
  `marks` varchar(200) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `evaluated_by` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `record_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_homeworks_evaluated_by_foreign` (`evaluated_by`),
  KEY `sm_homeworks_class_id_foreign` (`class_id`),
  KEY `sm_homeworks_subject_id_foreign` (`subject_id`),
  KEY `sm_homeworks_school_id_foreign` (`school_id`),
  KEY `sm_homeworks_academic_id_foreign` (`academic_id`),
  KEY `sm_homeworks_record_id_foreign` (`record_id`),
  CONSTRAINT `sm_homeworks_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_homeworks_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_homeworks_evaluated_by_foreign` FOREIGN KEY (`evaluated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_homeworks_record_id_foreign` FOREIGN KEY (`record_id`) REFERENCES `student_records` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_homeworks_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_homeworks_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_homework_students`;
CREATE TABLE `sm_homework_students` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `marks` varchar(200) DEFAULT NULL,
  `teacher_comments` varchar(255) DEFAULT NULL,
  `complete_status` varchar(200) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `homework_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_homework_students_student_id_foreign` (`student_id`),
  KEY `sm_homework_students_homework_id_foreign` (`homework_id`),
  KEY `sm_homework_students_school_id_foreign` (`school_id`),
  KEY `sm_homework_students_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_homework_students_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_homework_students_homework_id_foreign` FOREIGN KEY (`homework_id`) REFERENCES `sm_homeworks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_homework_students_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_homework_students_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_home_page_settings`;
CREATE TABLE `sm_home_page_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `long_title` varchar(255) DEFAULT NULL,
  `short_description` text DEFAULT NULL,
  `link_label` varchar(255) DEFAULT NULL,
  `link_url` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_home_page_settings_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_home_page_settings_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_hourly_rates`;
CREATE TABLE `sm_hourly_rates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `grade` varchar(191) DEFAULT NULL,
  `rate` int(11) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_hourly_rates_school_id_foreign` (`school_id`),
  KEY `sm_hourly_rates_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_hourly_rates_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_hourly_rates_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_hr_payroll_earn_deducs`;
CREATE TABLE `sm_hr_payroll_earn_deducs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(191) DEFAULT NULL,
  `amount` double(10,2) DEFAULT NULL,
  `earn_dedc_type` varchar(5) DEFAULT NULL COMMENT 'e for earnings and d for deductions',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `payroll_generate_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_hr_payroll_earn_deducs_payroll_generate_id_foreign` (`payroll_generate_id`),
  KEY `sm_hr_payroll_earn_deducs_school_id_foreign` (`school_id`),
  KEY `sm_hr_payroll_earn_deducs_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_hr_payroll_earn_deducs_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_hr_payroll_earn_deducs_payroll_generate_id_foreign` FOREIGN KEY (`payroll_generate_id`) REFERENCES `sm_hr_payroll_generates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_hr_payroll_earn_deducs_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_hr_payroll_generates`;
CREATE TABLE `sm_hr_payroll_generates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `basic_salary` double DEFAULT NULL,
  `total_earning` double DEFAULT NULL,
  `total_deduction` double DEFAULT NULL,
  `gross_salary` double DEFAULT NULL,
  `tax` double DEFAULT NULL,
  `net_salary` double DEFAULT NULL,
  `payroll_month` varchar(191) DEFAULT NULL,
  `payroll_year` varchar(191) DEFAULT NULL,
  `payroll_status` varchar(191) DEFAULT NULL COMMENT 'NG for not generated, G for generated, P for paid',
  `payment_mode` varchar(191) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `staff_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_hr_payroll_generates_staff_id_foreign` (`staff_id`),
  KEY `sm_hr_payroll_generates_school_id_foreign` (`school_id`),
  KEY `sm_hr_payroll_generates_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_hr_payroll_generates_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_hr_payroll_generates_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_hr_payroll_generates_staff_id_foreign` FOREIGN KEY (`staff_id`) REFERENCES `sm_staffs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_hr_salary_templates`;
CREATE TABLE `sm_hr_salary_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `salary_grades` varchar(200) DEFAULT NULL,
  `salary_basic` varchar(200) DEFAULT NULL,
  `overtime_rate` varchar(200) DEFAULT NULL,
  `house_rent` int(11) DEFAULT NULL,
  `provident_fund` int(11) DEFAULT NULL,
  `gross_salary` int(11) DEFAULT NULL,
  `total_deduction` int(11) DEFAULT NULL,
  `net_salary` int(11) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_hr_salary_templates_school_id_foreign` (`school_id`),
  KEY `sm_hr_salary_templates_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_hr_salary_templates_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_hr_salary_templates_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_human_departments`;
CREATE TABLE `sm_human_departments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `is_saas` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `sm_human_departments_created_by_foreign` (`created_by`),
  KEY `sm_human_departments_updated_by_foreign` (`updated_by`),
  KEY `sm_human_departments_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_human_departments_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_human_departments_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_human_departments_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_income_heads`;
CREATE TABLE `sm_income_heads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_income_heads_school_id_foreign` (`school_id`),
  KEY `sm_income_heads_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_income_heads_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_income_heads_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_instructions`;
CREATE TABLE `sm_instructions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_instructions_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_instructions_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_inventory_payments`;
CREATE TABLE `sm_inventory_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_receive_sell_id` int(10) unsigned DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `amount` double(10,2) DEFAULT NULL,
  `reference_no` varchar(50) DEFAULT NULL,
  `payment_type` varchar(11) DEFAULT NULL COMMENT 'R for receive S for sell',
  `payment_method` int(10) unsigned DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_inventory_payments_school_id_foreign` (`school_id`),
  KEY `sm_inventory_payments_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_inventory_payments_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_inventory_payments_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_items`;
CREATE TABLE `sm_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_name` varchar(100) DEFAULT NULL,
  `total_in_stock` double(8,2) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `item_category_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_items_item_category_id_foreign` (`item_category_id`),
  KEY `sm_items_school_id_foreign` (`school_id`),
  KEY `sm_items_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_items_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_items_item_category_id_foreign` FOREIGN KEY (`item_category_id`) REFERENCES `sm_item_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_items_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_item_categories`;
CREATE TABLE `sm_item_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_item_categories_school_id_foreign` (`school_id`),
  KEY `sm_item_categories_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_item_categories_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_categories_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_item_issues`;
CREATE TABLE `sm_item_issues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `issue_to` int(10) unsigned DEFAULT NULL,
  `issue_by` int(10) unsigned DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `quantity` int(10) unsigned DEFAULT NULL,
  `issue_status` varchar(191) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `item_category_id` int(10) unsigned DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_item_issues_role_id_foreign` (`role_id`),
  KEY `sm_item_issues_item_category_id_foreign` (`item_category_id`),
  KEY `sm_item_issues_item_id_foreign` (`item_id`),
  KEY `sm_item_issues_school_id_foreign` (`school_id`),
  KEY `sm_item_issues_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_item_issues_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_issues_item_category_id_foreign` FOREIGN KEY (`item_category_id`) REFERENCES `sm_item_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_issues_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `sm_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_issues_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_issues_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_item_receives`;
CREATE TABLE `sm_item_receives` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `receive_date` date DEFAULT NULL,
  `reference_no` varchar(191) DEFAULT NULL,
  `grand_total` int(11) DEFAULT NULL,
  `total_quantity` int(11) DEFAULT NULL,
  `total_paid` int(11) DEFAULT NULL,
  `total_due` int(11) DEFAULT NULL,
  `expense_head_id` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `payment_method` varchar(191) DEFAULT NULL,
  `paid_status` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `supplier_id` int(10) unsigned DEFAULT NULL,
  `store_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_item_receives_supplier_id_foreign` (`supplier_id`),
  KEY `sm_item_receives_store_id_foreign` (`store_id`),
  KEY `sm_item_receives_school_id_foreign` (`school_id`),
  KEY `sm_item_receives_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_item_receives_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_receives_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_receives_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `sm_item_stores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_receives_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `sm_suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_item_receive_children`;
CREATE TABLE `sm_item_receive_children` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `unit_price` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `sub_total` int(11) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `item_receive_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_item_receive_children_item_id_foreign` (`item_id`),
  KEY `sm_item_receive_children_item_receive_id_foreign` (`item_receive_id`),
  KEY `sm_item_receive_children_school_id_foreign` (`school_id`),
  KEY `sm_item_receive_children_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_item_receive_children_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_receive_children_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `sm_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_receive_children_item_receive_id_foreign` FOREIGN KEY (`item_receive_id`) REFERENCES `sm_item_receives` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_receive_children_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_item_sells`;
CREATE TABLE `sm_item_sells` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_staff_id` int(11) DEFAULT NULL,
  `sell_date` date DEFAULT NULL,
  `reference_no` varchar(50) DEFAULT NULL,
  `grand_total` int(11) DEFAULT NULL,
  `total_quantity` int(11) DEFAULT NULL,
  `total_paid` int(11) DEFAULT NULL,
  `total_due` int(11) DEFAULT NULL,
  `income_head_id` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `payment_method` varchar(191) DEFAULT NULL,
  `paid_status` varchar(191) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_item_sells_role_id_foreign` (`role_id`),
  KEY `sm_item_sells_school_id_foreign` (`school_id`),
  KEY `sm_item_sells_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_item_sells_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_sells_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_sells_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_item_sell_children`;
CREATE TABLE `sm_item_sell_children` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sell_price` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `sub_total` int(11) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `item_sell_id` int(10) unsigned DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_item_sell_children_school_id_foreign` (`school_id`),
  KEY `sm_item_sell_children_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_item_sell_children_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_sell_children_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_item_stores`;
CREATE TABLE `sm_item_stores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `store_name` varchar(100) DEFAULT NULL,
  `store_no` varchar(100) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_item_stores_school_id_foreign` (`school_id`),
  KEY `sm_item_stores_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_item_stores_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_item_stores_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_languages`;
CREATE TABLE `sm_languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_name` varchar(191) DEFAULT NULL,
  `native` varchar(191) DEFAULT NULL,
  `language_universal` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `lang_id` int(10) unsigned DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_languages_lang_id_foreign` (`lang_id`),
  KEY `sm_languages_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_languages_lang_id_foreign` FOREIGN KEY (`lang_id`) REFERENCES `languages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_languages_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_language_phrases`;
CREATE TABLE `sm_language_phrases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `modules` text DEFAULT NULL,
  `default_phrases` text DEFAULT NULL,
  `en` text DEFAULT NULL,
  `es` text DEFAULT NULL,
  `bn` text DEFAULT NULL,
  `fr` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_language_phrases_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_language_phrases_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


DROP TABLE IF EXISTS `sm_leave_deduction_infos`;
CREATE TABLE `sm_leave_deduction_infos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `payroll_id` int(11) DEFAULT NULL,
  `extra_leave` int(11) DEFAULT NULL,
  `salary_deduct` int(11) DEFAULT NULL,
  `pay_month` varchar(191) DEFAULT NULL,
  `pay_year` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) DEFAULT 0,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_leave_deduction_infos_school_id_foreign` (`school_id`),
  KEY `sm_leave_deduction_infos_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_leave_deduction_infos_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_leave_deduction_infos_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_leave_defines`;
CREATE TABLE `sm_leave_defines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `days` int(10) unsigned DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `total_days` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `sm_leave_defines_role_id_foreign` (`role_id`),
  KEY `sm_leave_defines_user_id_foreign` (`user_id`),
  KEY `sm_leave_defines_type_id_foreign` (`type_id`),
  KEY `sm_leave_defines_school_id_foreign` (`school_id`),
  KEY `sm_leave_defines_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_leave_defines_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_leave_defines_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_leave_defines_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_leave_defines_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `sm_leave_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_leave_defines_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_leave_requests`;
CREATE TABLE `sm_leave_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `apply_date` date DEFAULT NULL,
  `leave_from` date DEFAULT NULL,
  `leave_to` date DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `note` text DEFAULT NULL,
  `file` varchar(191) DEFAULT NULL,
  `approve_status` varchar(191) DEFAULT NULL COMMENT 'P for Pending, A for Approve, R for reject',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `leave_define_id` int(10) unsigned DEFAULT NULL,
  `staff_id` int(10) unsigned DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_leave_requests_leave_define_id_foreign` (`leave_define_id`),
  KEY `sm_leave_requests_staff_id_foreign` (`staff_id`),
  KEY `sm_leave_requests_role_id_foreign` (`role_id`),
  KEY `sm_leave_requests_type_id_foreign` (`type_id`),
  KEY `sm_leave_requests_school_id_foreign` (`school_id`),
  KEY `sm_leave_requests_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_leave_requests_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_leave_requests_leave_define_id_foreign` FOREIGN KEY (`leave_define_id`) REFERENCES `sm_leave_defines` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_leave_requests_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_leave_requests_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_leave_requests_staff_id_foreign` FOREIGN KEY (`staff_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_leave_requests_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `sm_leave_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_leave_types`;
CREATE TABLE `sm_leave_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) DEFAULT NULL,
  `total_days` int(10) unsigned DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_leave_types_school_id_foreign` (`school_id`),
  KEY `sm_leave_types_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_leave_types_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_leave_types_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_lessons`;
CREATE TABLE `sm_lessons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lesson_title` varchar(191) DEFAULT NULL,
  `active_status` int(11) NOT NULL DEFAULT 1,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_lessons_class_id_foreign` (`class_id`),
  KEY `sm_lessons_section_id_foreign` (`section_id`),
  KEY `sm_lessons_subject_id_foreign` (`subject_id`),
  KEY `sm_lessons_school_id_foreign` (`school_id`),
  KEY `sm_lessons_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_lessons_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lessons_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lessons_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lessons_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lessons_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_lesson_details`;
CREATE TABLE `sm_lesson_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lesson_id` int(11) NOT NULL,
  `lesson_title` varchar(191) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `active_status` int(11) NOT NULL DEFAULT 1,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_lesson_details_class_id_foreign` (`class_id`),
  KEY `sm_lesson_details_section_id_foreign` (`section_id`),
  KEY `sm_lesson_details_subject_id_foreign` (`subject_id`),
  KEY `sm_lesson_details_school_id_foreign` (`school_id`),
  KEY `sm_lesson_details_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_lesson_details_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lesson_details_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lesson_details_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lesson_details_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lesson_details_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_lesson_topics`;
CREATE TABLE `sm_lesson_topics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lesson_id` int(11) NOT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `active_status` int(11) NOT NULL DEFAULT 1,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_lesson_topics_class_id_foreign` (`class_id`),
  KEY `sm_lesson_topics_section_id_foreign` (`section_id`),
  KEY `sm_lesson_topics_subject_id_foreign` (`subject_id`),
  KEY `sm_lesson_topics_school_id_foreign` (`school_id`),
  KEY `sm_lesson_topics_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_lesson_topics_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lesson_topics_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lesson_topics_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lesson_topics_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lesson_topics_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_lesson_topic_details`;
CREATE TABLE `sm_lesson_topic_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lesson_id` int(11) DEFAULT NULL,
  `topic_title` varchar(191) NOT NULL,
  `completed_status` varchar(191) DEFAULT NULL,
  `competed_date` date DEFAULT NULL,
  `active_status` int(11) NOT NULL DEFAULT 1,
  `topic_id` int(10) unsigned DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_lesson_topic_details_topic_id_foreign` (`topic_id`),
  KEY `sm_lesson_topic_details_school_id_foreign` (`school_id`),
  KEY `sm_lesson_topic_details_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_lesson_topic_details_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lesson_topic_details_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_lesson_topic_details_topic_id_foreign` FOREIGN KEY (`topic_id`) REFERENCES `sm_lesson_topics` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_library_members`;
CREATE TABLE `sm_library_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_ud_id` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `member_type` int(10) unsigned DEFAULT NULL,
  `student_staff_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_library_members_member_type_foreign` (`member_type`),
  KEY `sm_library_members_student_staff_id_foreign` (`student_staff_id`),
  KEY `sm_library_members_school_id_foreign` (`school_id`),
  KEY `sm_library_members_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_library_members_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_library_members_member_type_foreign` FOREIGN KEY (`member_type`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_library_members_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_library_members_student_staff_id_foreign` FOREIGN KEY (`student_staff_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_marks_grades`;
CREATE TABLE `sm_marks_grades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `grade_name` varchar(191) DEFAULT NULL,
  `gpa` double(8,2) DEFAULT NULL,
  `from` double(8,2) DEFAULT NULL,
  `up` double(8,2) DEFAULT NULL,
  `percent_from` double(8,2) DEFAULT NULL,
  `percent_upto` double(8,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_marks_grades_school_id_foreign` (`school_id`),
  KEY `sm_marks_grades_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_marks_grades_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_marks_grades_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_marks_registers`;
CREATE TABLE `sm_marks_registers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `exam_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_marks_registers_student_id_foreign` (`student_id`),
  KEY `sm_marks_registers_exam_id_foreign` (`exam_id`),
  KEY `sm_marks_registers_class_id_foreign` (`class_id`),
  KEY `sm_marks_registers_section_id_foreign` (`section_id`),
  KEY `sm_marks_registers_school_id_foreign` (`school_id`),
  KEY `sm_marks_registers_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_marks_registers_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_marks_registers_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_marks_registers_exam_id_foreign` FOREIGN KEY (`exam_id`) REFERENCES `sm_exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_marks_registers_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_marks_registers_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_marks_registers_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_marks_register_children`;
CREATE TABLE `sm_marks_register_children` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `marks` int(11) DEFAULT NULL,
  `abs` int(11) NOT NULL DEFAULT 0 COMMENT '1 for absent, 0 for present',
  `gpa_point` double(8,2) DEFAULT NULL,
  `gpa_grade` varchar(55) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `marks_register_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_marks_register_children_marks_register_id_foreign` (`marks_register_id`),
  KEY `sm_marks_register_children_subject_id_foreign` (`subject_id`),
  KEY `sm_marks_register_children_school_id_foreign` (`school_id`),
  KEY `sm_marks_register_children_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_marks_register_children_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_marks_register_children_marks_register_id_foreign` FOREIGN KEY (`marks_register_id`) REFERENCES `sm_marks_registers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_marks_register_children_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_marks_register_children_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_marks_send_sms`;
CREATE TABLE `sm_marks_send_sms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sms_send_status` tinyint(4) NOT NULL DEFAULT 1,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `exam_id` int(10) unsigned DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_marks_send_sms_exam_id_foreign` (`exam_id`),
  KEY `sm_marks_send_sms_student_id_foreign` (`student_id`),
  KEY `sm_marks_send_sms_school_id_foreign` (`school_id`),
  KEY `sm_marks_send_sms_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_marks_send_sms_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_marks_send_sms_exam_id_foreign` FOREIGN KEY (`exam_id`) REFERENCES `sm_exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_marks_send_sms_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_marks_send_sms_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_mark_stores`;
CREATE TABLE `sm_mark_stores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_roll_no` int(11) NOT NULL DEFAULT 1,
  `student_addmission_no` int(11) NOT NULL DEFAULT 1,
  `total_marks` double(8,2) NOT NULL DEFAULT 0.00,
  `is_absent` tinyint(4) NOT NULL DEFAULT 1,
  `teacher_remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `exam_term_id` int(10) unsigned DEFAULT NULL,
  `exam_setup_id` int(10) unsigned DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `student_record_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_mark_stores_subject_id_foreign` (`subject_id`),
  KEY `sm_mark_stores_exam_term_id_foreign` (`exam_term_id`),
  KEY `sm_mark_stores_exam_setup_id_foreign` (`exam_setup_id`),
  KEY `sm_mark_stores_student_id_foreign` (`student_id`),
  KEY `sm_mark_stores_class_id_foreign` (`class_id`),
  KEY `sm_mark_stores_section_id_foreign` (`section_id`),
  KEY `sm_mark_stores_school_id_foreign` (`school_id`),
  KEY `sm_mark_stores_academic_id_foreign` (`academic_id`),
  KEY `sm_mark_stores_student_record_id_foreign` (`student_record_id`),
  CONSTRAINT `sm_mark_stores_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_mark_stores_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_mark_stores_exam_setup_id_foreign` FOREIGN KEY (`exam_setup_id`) REFERENCES `sm_exam_setups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_mark_stores_exam_term_id_foreign` FOREIGN KEY (`exam_term_id`) REFERENCES `sm_exam_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_mark_stores_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_mark_stores_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_mark_stores_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_mark_stores_student_record_id_foreign` FOREIGN KEY (`student_record_id`) REFERENCES `student_records` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_mark_stores_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_modules`;
CREATE TABLE `sm_modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_modules_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_modules_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_module_links`;
CREATE TABLE `sm_module_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `route` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_module_links_module_id_foreign` (`module_id`),
  KEY `sm_module_links_created_by_foreign` (`created_by`),
  KEY `sm_module_links_updated_by_foreign` (`updated_by`),
  KEY `sm_module_links_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_module_links_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_module_links_module_id_foreign` FOREIGN KEY (`module_id`) REFERENCES `sm_modules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_module_links_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_module_links_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_module_permissions`;
CREATE TABLE `sm_module_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dashboard_id` int(11) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_module_permissions_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_module_permissions_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_module_permission_assigns`;
CREATE TABLE `sm_module_permission_assigns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `module_id` int(10) unsigned DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_module_permission_assigns_module_id_foreign` (`module_id`),
  KEY `sm_module_permission_assigns_role_id_foreign` (`role_id`),
  KEY `sm_module_permission_assigns_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_module_permission_assigns_module_id_foreign` FOREIGN KEY (`module_id`) REFERENCES `sm_module_permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_module_permission_assigns_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_module_permission_assigns_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_news`;
CREATE TABLE `sm_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `news_title` varchar(191) NOT NULL,
  `view_count` int(11) DEFAULT NULL,
  `active_status` int(11) DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `image_thumb` varchar(191) DEFAULT NULL,
  `news_body` longtext DEFAULT NULL,
  `publish_date` date DEFAULT NULL,
  `order` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_news_category_id_foreign` (`category_id`),
  CONSTRAINT `sm_news_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `sm_news_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_news_categories`;
CREATE TABLE `sm_news_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL DEFAULT 'news',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` bigint(20) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_news_pages`;
CREATE TABLE `sm_news_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `main_title` varchar(191) DEFAULT NULL,
  `main_description` text DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `main_image` varchar(191) DEFAULT NULL,
  `button_text` varchar(191) DEFAULT NULL,
  `button_url` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_news_pages_created_by_foreign` (`created_by`),
  KEY `sm_news_pages_updated_by_foreign` (`updated_by`),
  KEY `sm_news_pages_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_news_pages_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_news_pages_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_news_pages_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_notice_boards`;
CREATE TABLE `sm_notice_boards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notice_title` varchar(200) DEFAULT NULL,
  `notice_message` text DEFAULT NULL,
  `notice_date` date DEFAULT NULL,
  `publish_on` date DEFAULT NULL,
  `inform_to` varchar(200) DEFAULT NULL COMMENT 'Notice message sent to these roles',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `is_published` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_notice_boards_school_id_foreign` (`school_id`),
  KEY `sm_notice_boards_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_notice_boards_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_notice_boards_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_notifications`;
CREATE TABLE `sm_notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `message` varchar(191) DEFAULT NULL,
  `url` varchar(191) DEFAULT NULL,
  `is_read` tinyint(4) NOT NULL DEFAULT 0,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT 1,
  `role_id` int(10) unsigned NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned NOT NULL DEFAULT 1,
  `updated_by` int(10) unsigned NOT NULL DEFAULT 1,
  `school_id` int(10) unsigned NOT NULL DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_notifications_school_id_foreign` (`school_id`),
  KEY `sm_notifications_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_notifications_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_notifications_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_online_exams`;
CREATE TABLE `sm_online_exams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `start_time` varchar(200) DEFAULT NULL,
  `end_time` varchar(200) DEFAULT NULL,
  `end_date_time` varchar(191) DEFAULT NULL,
  `percentage` int(11) DEFAULT NULL,
  `instruction` text DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL COMMENT '0 = Pending 1 Published',
  `is_taken` tinyint(4) DEFAULT 0,
  `is_closed` tinyint(4) DEFAULT 0,
  `is_waiting` tinyint(4) DEFAULT 0,
  `is_running` tinyint(4) DEFAULT 0,
  `auto_mark` tinyint(4) DEFAULT 0,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_online_exams_class_id_foreign` (`class_id`),
  KEY `sm_online_exams_section_id_foreign` (`section_id`),
  KEY `sm_online_exams_subject_id_foreign` (`subject_id`),
  KEY `sm_online_exams_school_id_foreign` (`school_id`),
  KEY `sm_online_exams_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_online_exams_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exams_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exams_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exams_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exams_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_online_exam_marks`;
CREATE TABLE `sm_online_exam_marks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `marks` int(11) DEFAULT NULL,
  `abs` int(11) NOT NULL DEFAULT 0,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `exam_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_online_exam_marks_student_id_foreign` (`student_id`),
  KEY `sm_online_exam_marks_subject_id_foreign` (`subject_id`),
  KEY `sm_online_exam_marks_exam_id_foreign` (`exam_id`),
  KEY `sm_online_exam_marks_school_id_foreign` (`school_id`),
  KEY `sm_online_exam_marks_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_online_exam_marks_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exam_marks_exam_id_foreign` FOREIGN KEY (`exam_id`) REFERENCES `sm_exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exam_marks_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exam_marks_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exam_marks_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_online_exam_questions`;
CREATE TABLE `sm_online_exam_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(1) DEFAULT NULL,
  `mark` int(11) DEFAULT NULL,
  `title` text DEFAULT NULL,
  `trueFalse` varchar(1) DEFAULT NULL COMMENT 'F = false, T = true ',
  `suitable_words` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `online_exam_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_online_exam_questions_online_exam_id_foreign` (`online_exam_id`),
  KEY `sm_online_exam_questions_school_id_foreign` (`school_id`),
  KEY `sm_online_exam_questions_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_online_exam_questions_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exam_questions_online_exam_id_foreign` FOREIGN KEY (`online_exam_id`) REFERENCES `sm_online_exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exam_questions_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_online_exam_question_assigns`;
CREATE TABLE `sm_online_exam_question_assigns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `online_exam_id` int(10) unsigned DEFAULT NULL,
  `question_bank_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_online_exam_question_assigns_online_exam_id_foreign` (`online_exam_id`),
  KEY `sm_online_exam_question_assigns_question_bank_id_foreign` (`question_bank_id`),
  KEY `sm_online_exam_question_assigns_school_id_foreign` (`school_id`),
  KEY `sm_online_exam_question_assigns_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_online_exam_question_assigns_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exam_question_assigns_online_exam_id_foreign` FOREIGN KEY (`online_exam_id`) REFERENCES `sm_online_exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exam_question_assigns_question_bank_id_foreign` FOREIGN KEY (`question_bank_id`) REFERENCES `sm_question_banks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exam_question_assigns_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_online_exam_question_mu_options`;
CREATE TABLE `sm_online_exam_question_mu_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL COMMENT '0 unchecked 1 checked',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `online_exam_question_id` int(10) unsigned DEFAULT NULL COMMENT 'here we use foreign key shorter name',
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `on_ex_qu_id` (`online_exam_question_id`),
  KEY `sm_online_exam_question_mu_options_school_id_foreign` (`school_id`),
  KEY `sm_online_exam_question_mu_options_academic_id_foreign` (`academic_id`),
  CONSTRAINT `on_ex_qu_id` FOREIGN KEY (`online_exam_question_id`) REFERENCES `sm_online_exam_questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exam_question_mu_options_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_online_exam_question_mu_options_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_optional_subject_assigns`;
CREATE TABLE `sm_optional_subject_assigns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `session_id` int(10) unsigned NOT NULL,
  `academic_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_optional_subject_assigns_student_id_foreign` (`student_id`),
  KEY `sm_optional_subject_assigns_subject_id_foreign` (`subject_id`),
  KEY `sm_optional_subject_assigns_school_id_foreign` (`school_id`),
  KEY `sm_optional_subject_assigns_session_id_foreign` (`session_id`),
  KEY `sm_optional_subject_assigns_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_optional_subject_assigns_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_optional_subject_assigns_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_optional_subject_assigns_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_optional_subject_assigns_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_optional_subject_assigns_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_pages`;
CREATE TABLE `sm_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `sub_title` varchar(191) DEFAULT NULL,
  `slug` varchar(191) DEFAULT NULL,
  `header_image` text DEFAULT NULL,
  `details` longtext DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sm_pages_sub_title_unique` (`sub_title`),
  KEY `sm_pages_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_pages_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_parents`;
CREATE TABLE `sm_parents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fathers_name` varchar(200) DEFAULT NULL,
  `fathers_mobile` varchar(200) DEFAULT NULL,
  `fathers_occupation` varchar(200) DEFAULT NULL,
  `fathers_photo` varchar(200) DEFAULT NULL,
  `mothers_name` varchar(200) DEFAULT NULL,
  `mothers_mobile` varchar(200) DEFAULT NULL,
  `mothers_occupation` varchar(200) DEFAULT NULL,
  `mothers_photo` varchar(200) DEFAULT NULL,
  `relation` varchar(200) DEFAULT NULL,
  `guardians_name` varchar(200) DEFAULT NULL,
  `guardians_mobile` varchar(200) DEFAULT NULL,
  `guardians_email` varchar(200) DEFAULT NULL,
  `guardians_occupation` varchar(200) DEFAULT NULL,
  `guardians_relation` varchar(30) DEFAULT NULL,
  `guardians_photo` varchar(200) DEFAULT NULL,
  `guardians_address` varchar(200) DEFAULT NULL,
  `is_guardian` int(11) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_parents_user_id_foreign` (`user_id`),
  KEY `sm_parents_school_id_foreign` (`school_id`),
  KEY `sm_parents_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_parents_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_parents_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_parents_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_payment_gateway_settings`;
CREATE TABLE `sm_payment_gateway_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_name` varchar(191) DEFAULT NULL,
  `gateway_username` varchar(191) DEFAULT NULL,
  `gateway_password` varchar(191) DEFAULT NULL,
  `gateway_signature` varchar(191) DEFAULT NULL,
  `gateway_client_id` varchar(191) DEFAULT NULL,
  `gateway_mode` varchar(191) DEFAULT NULL,
  `gateway_secret_key` varchar(191) DEFAULT NULL,
  `gateway_secret_word` varchar(191) DEFAULT NULL,
  `gateway_publisher_key` varchar(191) DEFAULT NULL,
  `gateway_private_key` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bank_details` text DEFAULT NULL,
  `cheque_details` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_payment_gateway_settings_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_payment_gateway_settings_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_payment_methhods`;
CREATE TABLE `sm_payment_methhods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `method` varchar(255) NOT NULL,
  `type` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `gateway_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_payment_methhods_gateway_id_foreign` (`gateway_id`),
  KEY `sm_payment_methhods_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_payment_methhods_gateway_id_foreign` FOREIGN KEY (`gateway_id`) REFERENCES `sm_payment_gateway_settings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_payment_methhods_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_phone_call_logs`;
CREATE TABLE `sm_phone_call_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `next_follow_up_date` date DEFAULT NULL,
  `call_duration` varchar(100) DEFAULT NULL,
  `call_type` varchar(2) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_phone_call_logs_school_id_foreign` (`school_id`),
  KEY `sm_phone_call_logs_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_phone_call_logs_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_phone_call_logs_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_postal_dispatches`;
CREATE TABLE `sm_postal_dispatches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `to_title` varchar(191) DEFAULT NULL,
  `from_title` varchar(191) DEFAULT NULL,
  `reference_no` varchar(191) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `file` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_postal_dispatches_school_id_foreign` (`school_id`),
  KEY `sm_postal_dispatches_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_postal_dispatches_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_postal_dispatches_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_postal_receives`;
CREATE TABLE `sm_postal_receives` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from_title` varchar(191) DEFAULT NULL,
  `to_title` varchar(191) DEFAULT NULL,
  `reference_no` varchar(191) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `file` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_postal_receives_school_id_foreign` (`school_id`),
  KEY `sm_postal_receives_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_postal_receives_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_postal_receives_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_product_purchases`;
CREATE TABLE `sm_product_purchases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_date` date NOT NULL,
  `expaire_date` date NOT NULL,
  `price` double(10,2) DEFAULT NULL,
  `paid_amount` double(10,2) DEFAULT NULL,
  `due_amount` double(10,2) DEFAULT NULL,
  `package` varchar(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `staff_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_product_purchases_user_id_foreign` (`user_id`),
  KEY `sm_product_purchases_staff_id_foreign` (`staff_id`),
  KEY `sm_product_purchases_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_product_purchases_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_product_purchases_staff_id_foreign` FOREIGN KEY (`staff_id`) REFERENCES `sm_staffs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_product_purchases_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_question_banks`;
CREATE TABLE `sm_question_banks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(2) NOT NULL COMMENT 'M for multi ans, T for trueFalse, F for fill in the blanks',
  `question` text DEFAULT NULL,
  `marks` int(11) DEFAULT NULL,
  `trueFalse` varchar(1) DEFAULT NULL COMMENT 'F = false, T = true ',
  `suitable_words` text DEFAULT NULL,
  `number_of_option` varchar(2) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `q_group_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_question_banks_q_group_id_foreign` (`q_group_id`),
  KEY `sm_question_banks_class_id_foreign` (`class_id`),
  KEY `sm_question_banks_section_id_foreign` (`section_id`),
  KEY `sm_question_banks_school_id_foreign` (`school_id`),
  KEY `sm_question_banks_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_question_banks_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_question_banks_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_question_banks_q_group_id_foreign` FOREIGN KEY (`q_group_id`) REFERENCES `sm_question_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_question_banks_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_question_banks_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_question_bank_mu_options`;
CREATE TABLE `sm_question_bank_mu_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL COMMENT '0 = false, 1 = correct',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `question_bank_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_question_bank_mu_options_question_bank_id_foreign` (`question_bank_id`),
  KEY `sm_question_bank_mu_options_school_id_foreign` (`school_id`),
  KEY `sm_question_bank_mu_options_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_question_bank_mu_options_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_question_bank_mu_options_question_bank_id_foreign` FOREIGN KEY (`question_bank_id`) REFERENCES `sm_question_banks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_question_bank_mu_options_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_question_groups`;
CREATE TABLE `sm_question_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_question_groups_school_id_foreign` (`school_id`),
  KEY `sm_question_groups_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_question_groups_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_question_groups_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_question_levels`;
CREATE TABLE `sm_question_levels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level` varchar(200) NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_question_levels_school_id_foreign` (`school_id`),
  KEY `sm_question_levels_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_question_levels_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_question_levels_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_result_stores`;
CREATE TABLE `sm_result_stores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_roll_no` int(11) NOT NULL DEFAULT 1,
  `student_addmission_no` int(11) NOT NULL DEFAULT 1,
  `is_absent` int(11) NOT NULL DEFAULT 0 COMMENT '1=Absent, 0=Present',
  `total_marks` double(8,2) NOT NULL DEFAULT 0.00,
  `total_gpa_point` double(8,2) DEFAULT NULL,
  `total_gpa_grade` varchar(255) DEFAULT '0',
  `teacher_remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `exam_type_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `exam_setup_id` int(10) unsigned DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `student_record_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_result_stores_exam_type_id_foreign` (`exam_type_id`),
  KEY `sm_result_stores_subject_id_foreign` (`subject_id`),
  KEY `sm_result_stores_exam_setup_id_foreign` (`exam_setup_id`),
  KEY `sm_result_stores_student_id_foreign` (`student_id`),
  KEY `sm_result_stores_class_id_foreign` (`class_id`),
  KEY `sm_result_stores_section_id_foreign` (`section_id`),
  KEY `sm_result_stores_school_id_foreign` (`school_id`),
  KEY `sm_result_stores_academic_id_foreign` (`academic_id`),
  KEY `sm_result_stores_student_record_id_foreign` (`student_record_id`),
  CONSTRAINT `sm_result_stores_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_result_stores_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_result_stores_exam_setup_id_foreign` FOREIGN KEY (`exam_setup_id`) REFERENCES `sm_exam_setups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_result_stores_exam_type_id_foreign` FOREIGN KEY (`exam_type_id`) REFERENCES `sm_exam_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_result_stores_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_result_stores_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_result_stores_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_result_stores_student_record_id_foreign` FOREIGN KEY (`student_record_id`) REFERENCES `student_records` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_result_stores_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_role_permissions`;
CREATE TABLE `sm_role_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `module_link_id` int(10) unsigned DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_role_permissions_module_link_id_foreign` (`module_link_id`),
  KEY `sm_role_permissions_role_id_foreign` (`role_id`),
  KEY `sm_role_permissions_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_role_permissions_module_link_id_foreign` FOREIGN KEY (`module_link_id`) REFERENCES `sm_module_links` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_role_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sm_role_permissions_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_room_lists`;
CREATE TABLE `sm_room_lists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `number_of_bed` int(11) NOT NULL,
  `cost_per_bed` double(16,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `dormitory_id` int(10) unsigned DEFAULT 1,
  `room_type_id` int(10) unsigned DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_room_lists_dormitory_id_foreign` (`dormitory_id`),
  KEY `sm_room_lists_room_type_id_foreign` (`room_type_id`),
  KEY `sm_room_lists_school_id_foreign` (`school_id`),
  KEY `sm_room_lists_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_room_lists_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_room_lists_dormitory_id_foreign` FOREIGN KEY (`dormitory_id`) REFERENCES `sm_dormitory_lists` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_room_lists_room_type_id_foreign` FOREIGN KEY (`room_type_id`) REFERENCES `sm_room_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_room_lists_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_room_types`;
CREATE TABLE `sm_room_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_room_types_school_id_foreign` (`school_id`),
  KEY `sm_room_types_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_room_types_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_room_types_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_routes`;
CREATE TABLE `sm_routes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `far` double(10,2) NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_routes_school_id_foreign` (`school_id`),
  KEY `sm_routes_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_routes_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_routes_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_schools`;
CREATE TABLE `sm_schools` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_name` varchar(200) DEFAULT NULL,
  `created_by` tinyint(4) NOT NULL DEFAULT 1,
  `updated_by` tinyint(4) NOT NULL DEFAULT 1,
  `email` varchar(200) DEFAULT NULL,
  `domain` varchar(191) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `school_code` varchar(200) DEFAULT NULL,
  `is_email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `starting_date` date DEFAULT NULL,
  `ending_date` date DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `plan_type` varchar(200) DEFAULT NULL,
  `contact_type` enum('yearly','monthly','once') NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 approved, 0 pending',
  `is_enabled` varchar(20) NOT NULL DEFAULT 'yes' COMMENT 'yes=Login enable, no=Login disable',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_seat_plans`;
CREATE TABLE `sm_seat_plans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `exam_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_seat_plans_exam_id_foreign` (`exam_id`),
  KEY `sm_seat_plans_subject_id_foreign` (`subject_id`),
  KEY `sm_seat_plans_class_id_foreign` (`class_id`),
  KEY `sm_seat_plans_section_id_foreign` (`section_id`),
  KEY `sm_seat_plans_school_id_foreign` (`school_id`),
  KEY `sm_seat_plans_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_seat_plans_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_seat_plans_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_seat_plans_exam_id_foreign` FOREIGN KEY (`exam_id`) REFERENCES `sm_exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_seat_plans_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_seat_plans_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_seat_plans_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_seat_plan_children`;
CREATE TABLE `sm_seat_plan_children` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_id` tinyint(4) DEFAULT NULL,
  `assign_students` int(11) DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `seat_plan_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_seat_plan_children_seat_plan_id_foreign` (`seat_plan_id`),
  KEY `sm_seat_plan_children_school_id_foreign` (`school_id`),
  KEY `sm_seat_plan_children_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_seat_plan_children_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_seat_plan_children_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_seat_plan_children_seat_plan_id_foreign` FOREIGN KEY (`seat_plan_id`) REFERENCES `sm_seat_plans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_sections`;
CREATE TABLE `sm_sections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `section_name` varchar(200) NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_sections_school_id_foreign` (`school_id`),
  KEY `sm_sections_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_sections_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_sections_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_send_messages`;
CREATE TABLE `sm_send_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_title` varchar(200) DEFAULT NULL,
  `message_des` varchar(500) DEFAULT NULL,
  `notice_date` date DEFAULT NULL,
  `publish_on` date DEFAULT NULL,
  `message_to` varchar(200) DEFAULT NULL COMMENT 'message sent to these roles',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_send_messages_school_id_foreign` (`school_id`),
  KEY `sm_send_messages_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_send_messages_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_send_messages_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_sessions`;
CREATE TABLE `sm_sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session` varchar(255) NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_sessions_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_sessions_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_setup_admins`;
CREATE TABLE `sm_setup_admins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT NULL COMMENT '1 purpose, 2 complaint type, 3 source, 4 Reference',
  `name` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_setup_admins_school_id_foreign` (`school_id`),
  KEY `sm_setup_admins_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_setup_admins_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_setup_admins_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_sms_gateways`;
CREATE TABLE `sm_sms_gateways` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_name` varchar(255) DEFAULT NULL,
  `clickatell_username` varchar(255) DEFAULT NULL,
  `clickatell_password` varchar(255) DEFAULT NULL,
  `clickatell_api_id` varchar(255) DEFAULT NULL,
  `twilio_account_sid` varchar(255) DEFAULT NULL,
  `twilio_authentication_token` varchar(255) DEFAULT NULL,
  `twilio_registered_no` varchar(255) DEFAULT NULL,
  `msg91_authentication_key_sid` varchar(255) DEFAULT NULL,
  `msg91_sender_id` varchar(255) DEFAULT NULL,
  `msg91_route` varchar(255) DEFAULT NULL,
  `msg91_country_code` varchar(255) DEFAULT NULL,
  `textlocal_username` varchar(255) DEFAULT NULL,
  `textlocal_hash` varchar(255) DEFAULT NULL,
  `textlocal_sender` varchar(255) DEFAULT NULL,
  `device_info` text DEFAULT NULL,
  `africatalking_username` varchar(255) DEFAULT NULL,
  `africatalking_api_key` varchar(255) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_sms_gateways_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_sms_gateways_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_social_media_icons`;
CREATE TABLE `sm_social_media_icons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(191) DEFAULT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '1 active, 0 inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_social_media_icons_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_social_media_icons_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_staffs`;
CREATE TABLE `sm_staffs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `staff_no` int(11) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `full_name` varchar(200) DEFAULT NULL,
  `fathers_name` varchar(100) DEFAULT NULL,
  `mothers_name` varchar(100) DEFAULT NULL,
  `date_of_birth` date DEFAULT '2022-07-24',
  `date_of_joining` date DEFAULT '2022-07-24',
  `email` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `emergency_mobile` varchar(50) DEFAULT NULL,
  `marital_status` varchar(30) DEFAULT NULL,
  `merital_status` varchar(30) DEFAULT NULL,
  `staff_photo` varchar(191) DEFAULT NULL,
  `current_address` varchar(500) DEFAULT NULL,
  `permanent_address` varchar(500) DEFAULT NULL,
  `qualification` varchar(200) DEFAULT NULL,
  `experience` varchar(200) DEFAULT NULL,
  `epf_no` varchar(20) DEFAULT NULL,
  `basic_salary` varchar(200) DEFAULT NULL,
  `contract_type` varchar(200) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `casual_leave` varchar(15) DEFAULT NULL,
  `medical_leave` varchar(15) DEFAULT NULL,
  `metarnity_leave` varchar(15) DEFAULT NULL,
  `bank_account_name` varchar(50) DEFAULT NULL,
  `bank_account_no` varchar(50) DEFAULT NULL,
  `bank_name` varchar(20) DEFAULT NULL,
  `bank_brach` varchar(30) DEFAULT NULL,
  `facebook_url` varchar(100) DEFAULT NULL,
  `twiteer_url` varchar(100) DEFAULT NULL,
  `linkedin_url` varchar(100) DEFAULT NULL,
  `instragram_url` varchar(100) DEFAULT NULL,
  `joining_letter` varchar(500) DEFAULT NULL,
  `resume` varchar(500) DEFAULT NULL,
  `other_document` varchar(500) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `driving_license` varchar(255) DEFAULT NULL,
  `driving_license_ex_date` date DEFAULT NULL,
  `custom_field` text DEFAULT NULL,
  `custom_field_form_name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `designation_id` int(10) unsigned DEFAULT 1,
  `department_id` int(10) unsigned DEFAULT 1,
  `user_id` int(10) unsigned DEFAULT 1,
  `role_id` int(10) unsigned DEFAULT 1,
  `gender_id` int(10) unsigned DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `is_saas` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `sm_staffs_designation_id_foreign` (`designation_id`),
  KEY `sm_staffs_department_id_foreign` (`department_id`),
  KEY `sm_staffs_user_id_foreign` (`user_id`),
  KEY `sm_staffs_role_id_foreign` (`role_id`),
  KEY `sm_staffs_gender_id_foreign` (`gender_id`),
  KEY `sm_staffs_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_staffs_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `sm_human_departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_staffs_designation_id_foreign` FOREIGN KEY (`designation_id`) REFERENCES `sm_designations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_staffs_gender_id_foreign` FOREIGN KEY (`gender_id`) REFERENCES `sm_base_setups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_staffs_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `infix_roles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_staffs_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_staffs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_staff_attendance_imports`;
CREATE TABLE `sm_staff_attendance_imports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attendence_date` date DEFAULT NULL,
  `in_time` varchar(50) DEFAULT NULL,
  `out_time` varchar(50) DEFAULT NULL,
  `attendance_type` varchar(10) DEFAULT NULL COMMENT 'Present: P Late: L Absent: A Holiday: H Half Day: F',
  `notes` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `staff_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_staff_attendance_imports_staff_id_foreign` (`staff_id`),
  KEY `sm_staff_attendance_imports_school_id_foreign` (`school_id`),
  KEY `sm_staff_attendance_imports_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_staff_attendance_imports_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_staff_attendance_imports_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_staff_attendance_imports_staff_id_foreign` FOREIGN KEY (`staff_id`) REFERENCES `sm_staffs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_staff_attendences`;
CREATE TABLE `sm_staff_attendences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attendence_type` varchar(10) DEFAULT NULL COMMENT 'Present: P Late: L Absent: A Holiday: H Half Day: F',
  `notes` varchar(500) DEFAULT NULL,
  `attendence_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `staff_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_staff_attendences_staff_id_foreign` (`staff_id`),
  KEY `sm_staff_attendences_school_id_foreign` (`school_id`),
  KEY `sm_staff_attendences_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_staff_attendences_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_staff_attendences_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_staff_attendences_staff_id_foreign` FOREIGN KEY (`staff_id`) REFERENCES `sm_staffs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_staff_registration_fields`;
CREATE TABLE `sm_staff_registration_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `field_name` varchar(191) DEFAULT NULL,
  `label_name` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) DEFAULT 1,
  `is_required` tinyint(4) DEFAULT 0,
  `staff_edit` tinyint(4) DEFAULT 0,
  `required_type` tinyint(4) DEFAULT NULL COMMENT '1=switch on,2=off',
  `position` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_staff_registration_fields_school_id_foreign` (`school_id`),
  KEY `sm_staff_registration_fields_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_staff_registration_fields_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_staff_registration_fields_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_students`;
CREATE TABLE `sm_students` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admission_no` int(11) DEFAULT NULL,
  `roll_no` int(11) DEFAULT NULL,
  `first_name` varchar(200) DEFAULT NULL,
  `last_name` varchar(200) DEFAULT NULL,
  `full_name` varchar(200) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `caste` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `mobile` varchar(200) DEFAULT NULL,
  `admission_date` date DEFAULT NULL,
  `student_photo` varchar(191) DEFAULT NULL,
  `age` varchar(200) DEFAULT NULL,
  `height` varchar(200) DEFAULT NULL,
  `weight` varchar(200) DEFAULT NULL,
  `current_address` varchar(500) DEFAULT NULL,
  `permanent_address` varchar(500) DEFAULT NULL,
  `driver_id` varchar(200) DEFAULT NULL,
  `national_id_no` varchar(200) DEFAULT NULL,
  `local_id_no` varchar(200) DEFAULT NULL,
  `bank_account_no` varchar(200) DEFAULT NULL,
  `bank_name` varchar(200) DEFAULT NULL,
  `previous_school_details` varchar(500) DEFAULT NULL,
  `aditional_notes` varchar(500) DEFAULT NULL,
  `ifsc_code` varchar(50) DEFAULT NULL,
  `document_title_1` varchar(200) DEFAULT NULL,
  `document_file_1` varchar(200) DEFAULT NULL,
  `document_title_2` varchar(200) DEFAULT NULL,
  `document_file_2` varchar(200) DEFAULT NULL,
  `document_title_3` varchar(200) DEFAULT NULL,
  `document_file_3` varchar(200) DEFAULT NULL,
  `document_title_4` varchar(200) DEFAULT NULL,
  `document_file_4` varchar(200) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `custom_field` text DEFAULT NULL,
  `custom_field_form_name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bloodgroup_id` int(10) unsigned DEFAULT NULL,
  `religion_id` int(10) unsigned DEFAULT NULL,
  `route_list_id` int(10) unsigned DEFAULT NULL,
  `dormitory_id` int(10) unsigned DEFAULT NULL,
  `vechile_id` int(10) unsigned DEFAULT NULL,
  `room_id` int(10) unsigned DEFAULT NULL,
  `student_category_id` int(10) unsigned DEFAULT NULL,
  `student_group_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `session_id` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `gender_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned NOT NULL DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_students_bloodgroup_id_foreign` (`bloodgroup_id`),
  KEY `sm_students_religion_id_foreign` (`religion_id`),
  KEY `sm_students_route_list_id_foreign` (`route_list_id`),
  KEY `sm_students_dormitory_id_foreign` (`dormitory_id`),
  KEY `sm_students_vechile_id_foreign` (`vechile_id`),
  KEY `sm_students_room_id_foreign` (`room_id`),
  KEY `sm_students_student_category_id_foreign` (`student_category_id`),
  KEY `sm_students_student_group_id_foreign` (`student_group_id`),
  KEY `sm_students_class_id_foreign` (`class_id`),
  KEY `sm_students_section_id_foreign` (`section_id`),
  KEY `sm_students_session_id_foreign` (`session_id`),
  KEY `sm_students_parent_id_foreign` (`parent_id`),
  KEY `sm_students_user_id_foreign` (`user_id`),
  KEY `sm_students_role_id_foreign` (`role_id`),
  KEY `sm_students_gender_id_foreign` (`gender_id`),
  KEY `sm_students_school_id_foreign` (`school_id`),
  KEY `sm_students_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_students_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_students_bloodgroup_id_foreign` FOREIGN KEY (`bloodgroup_id`) REFERENCES `sm_base_setups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_students_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_students_dormitory_id_foreign` FOREIGN KEY (`dormitory_id`) REFERENCES `sm_dormitory_lists` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_students_gender_id_foreign` FOREIGN KEY (`gender_id`) REFERENCES `sm_base_setups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_students_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `sm_parents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_students_religion_id_foreign` FOREIGN KEY (`religion_id`) REFERENCES `sm_base_setups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_students_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `infix_roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_students_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `sm_room_lists` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_students_route_list_id_foreign` FOREIGN KEY (`route_list_id`) REFERENCES `sm_routes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_students_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_students_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_students_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_students_student_category_id_foreign` FOREIGN KEY (`student_category_id`) REFERENCES `sm_student_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_students_student_group_id_foreign` FOREIGN KEY (`student_group_id`) REFERENCES `sm_student_groups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_students_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_students_vechile_id_foreign` FOREIGN KEY (`vechile_id`) REFERENCES `sm_vehicles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_attendances`;
CREATE TABLE `sm_student_attendances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attendance_type` varchar(10) DEFAULT NULL COMMENT 'Present: P Late: L Absent: A Holiday: H Half Day: F',
  `notes` varchar(500) DEFAULT NULL,
  `attendance_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `student_record_id` bigint(20) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `record_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_student_attendances_student_id_foreign` (`student_id`),
  KEY `sm_student_attendances_school_id_foreign` (`school_id`),
  KEY `sm_student_attendances_academic_id_foreign` (`academic_id`),
  KEY `sm_student_attendances_student_record_id_foreign` (`student_record_id`),
  KEY `sm_student_attendances_class_id_foreign` (`class_id`),
  KEY `sm_student_attendances_section_id_foreign` (`section_id`),
  KEY `sm_student_attendances_record_id_foreign` (`record_id`),
  CONSTRAINT `sm_student_attendances_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_attendances_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_attendances_record_id_foreign` FOREIGN KEY (`record_id`) REFERENCES `student_records` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_attendances_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_attendances_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_attendances_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_attendances_student_record_id_foreign` FOREIGN KEY (`student_record_id`) REFERENCES `student_records` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_attendance_imports`;
CREATE TABLE `sm_student_attendance_imports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attendance_date` date DEFAULT NULL,
  `in_time` varchar(50) DEFAULT NULL,
  `out_time` varchar(50) DEFAULT NULL,
  `attendance_type` varchar(10) DEFAULT NULL COMMENT 'Present: P Late: L Absent: A Holiday: H Half Day: F',
  `notes` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_student_attendance_imports_student_id_foreign` (`student_id`),
  KEY `sm_student_attendance_imports_school_id_foreign` (`school_id`),
  KEY `sm_student_attendance_imports_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_student_attendance_imports_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_attendance_imports_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_attendance_imports_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_categories`;
CREATE TABLE `sm_student_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_student_categories_school_id_foreign` (`school_id`),
  KEY `sm_student_categories_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_student_categories_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_categories_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_certificates`;
CREATE TABLE `sm_student_certificates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `header_left_text` varchar(191) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `body` text DEFAULT NULL,
  `footer_left_text` varchar(191) DEFAULT NULL,
  `footer_center_text` varchar(191) DEFAULT NULL,
  `footer_right_text` varchar(191) DEFAULT NULL,
  `student_photo` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 = yes 0 no',
  `file` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_student_certificates_school_id_foreign` (`school_id`),
  KEY `sm_student_certificates_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_student_certificates_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_certificates_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_documents`;
CREATE TABLE `sm_student_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `student_staff_id` int(11) DEFAULT NULL,
  `type` varchar(191) DEFAULT NULL COMMENT 'stu=student,stf=staff',
  `file` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_student_documents_school_id_foreign` (`school_id`),
  KEY `sm_student_documents_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_student_documents_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_documents_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_excel_formats`;
CREATE TABLE `sm_student_excel_formats` (
  `roll_no` varchar(191) DEFAULT NULL,
  `first_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `date_of_birth` varchar(191) DEFAULT NULL,
  `religion` varchar(191) DEFAULT NULL,
  `caste` varchar(191) DEFAULT NULL,
  `mobile` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `admission_date` varchar(191) DEFAULT NULL,
  `category` varchar(191) DEFAULT NULL,
  `blood_group` varchar(191) DEFAULT NULL,
  `height` varchar(191) DEFAULT NULL,
  `weight` varchar(191) DEFAULT NULL,
  `siblings_id` varchar(191) DEFAULT NULL,
  `father_name` varchar(191) DEFAULT NULL,
  `father_phone` varchar(191) DEFAULT NULL,
  `father_occupation` varchar(191) DEFAULT NULL,
  `mother_name` varchar(191) DEFAULT NULL,
  `mother_phone` varchar(191) DEFAULT NULL,
  `mother_occupation` varchar(191) DEFAULT NULL,
  `guardian_name` varchar(191) DEFAULT NULL,
  `guardian_relation` varchar(191) DEFAULT NULL,
  `guardian_email` varchar(191) DEFAULT NULL,
  `guardian_phone` varchar(191) DEFAULT NULL,
  `guardian_occupation` varchar(191) DEFAULT NULL,
  `guardian_address` varchar(191) DEFAULT NULL,
  `current_address` varchar(191) DEFAULT NULL,
  `permanent_address` varchar(191) DEFAULT NULL,
  `bank_account_no` varchar(191) DEFAULT NULL,
  `bank_name` varchar(191) DEFAULT NULL,
  `national_identification_no` varchar(191) DEFAULT NULL,
  `local_identification_no` varchar(191) DEFAULT NULL,
  `previous_school_details` varchar(191) DEFAULT NULL,
  `note` varchar(191) DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  KEY `sm_student_excel_formats_school_id_foreign` (`school_id`),
  KEY `sm_student_excel_formats_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_student_excel_formats_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_excel_formats_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_groups`;
CREATE TABLE `sm_student_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group` varchar(200) NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_student_groups_school_id_foreign` (`school_id`),
  KEY `sm_student_groups_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_student_groups_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_groups_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_homeworks`;
CREATE TABLE `sm_student_homeworks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `homework_date` date DEFAULT NULL,
  `submission_date` date DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `percentage` varchar(200) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `evaluated_by` int(10) unsigned DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_student_homeworks_evaluated_by_foreign` (`evaluated_by`),
  KEY `sm_student_homeworks_student_id_foreign` (`student_id`),
  KEY `sm_student_homeworks_subject_id_foreign` (`subject_id`),
  KEY `sm_student_homeworks_school_id_foreign` (`school_id`),
  KEY `sm_student_homeworks_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_student_homeworks_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_homeworks_evaluated_by_foreign` FOREIGN KEY (`evaluated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_homeworks_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_homeworks_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_homeworks_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_id_cards`;
CREATE TABLE `sm_student_id_cards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `logo` varchar(191) DEFAULT NULL,
  `signature` varchar(191) DEFAULT NULL,
  `background_img` varchar(191) DEFAULT NULL,
  `profile_image` varchar(191) DEFAULT NULL,
  `role_id` text DEFAULT NULL,
  `page_layout_style` varchar(191) DEFAULT NULL,
  `user_photo_style` varchar(191) DEFAULT NULL,
  `user_photo_width` varchar(191) DEFAULT NULL,
  `user_photo_height` varchar(191) DEFAULT NULL,
  `pl_width` int(11) DEFAULT NULL,
  `pl_height` int(11) DEFAULT NULL,
  `t_space` int(11) DEFAULT NULL,
  `b_space` int(11) DEFAULT NULL,
  `r_space` int(11) DEFAULT NULL,
  `l_space` int(11) DEFAULT NULL,
  `admission_no` varchar(191) NOT NULL DEFAULT '0' COMMENT '0 for no 1 for yes',
  `student_name` varchar(191) NOT NULL DEFAULT '0' COMMENT '0 for no 1 for yes',
  `class` varchar(191) NOT NULL DEFAULT '0' COMMENT '0 for no 1 for yes',
  `father_name` varchar(191) NOT NULL DEFAULT '0' COMMENT '0 for no 1 for yes',
  `mother_name` varchar(191) NOT NULL DEFAULT '0' COMMENT '0 for no 1 for yes',
  `student_address` varchar(191) NOT NULL DEFAULT '0' COMMENT '0 for no 1 for yes',
  `phone_number` varchar(191) NOT NULL DEFAULT '0' COMMENT '0 for no 1 for yes',
  `dob` varchar(191) NOT NULL DEFAULT '0' COMMENT '0 for no 1 for yes',
  `blood` varchar(191) NOT NULL DEFAULT '0' COMMENT '0 for no 1 for yes',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_student_id_cards_school_id_foreign` (`school_id`),
  KEY `sm_student_id_cards_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_student_id_cards_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_id_cards_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_promotions`;
CREATE TABLE `sm_student_promotions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `result_status` varchar(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `previous_class_id` int(10) unsigned DEFAULT NULL,
  `current_class_id` int(10) unsigned DEFAULT NULL,
  `previous_section_id` int(10) unsigned DEFAULT NULL,
  `current_section_id` int(10) unsigned DEFAULT NULL,
  `previous_session_id` int(10) unsigned DEFAULT NULL,
  `current_session_id` int(10) unsigned DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `admission_number` int(11) DEFAULT NULL,
  `student_info` longtext DEFAULT NULL,
  `merit_student_info` longtext DEFAULT NULL,
  `previous_roll_number` int(11) DEFAULT NULL,
  `current_roll_number` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_student_promotions_previous_class_id_foreign` (`previous_class_id`),
  KEY `sm_student_promotions_current_class_id_foreign` (`current_class_id`),
  KEY `sm_student_promotions_previous_section_id_foreign` (`previous_section_id`),
  KEY `sm_student_promotions_current_section_id_foreign` (`current_section_id`),
  KEY `sm_student_promotions_previous_session_id_foreign` (`previous_session_id`),
  KEY `sm_student_promotions_current_session_id_foreign` (`current_session_id`),
  KEY `sm_student_promotions_student_id_foreign` (`student_id`),
  KEY `sm_student_promotions_school_id_foreign` (`school_id`),
  KEY `sm_student_promotions_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_student_promotions_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_promotions_current_class_id_foreign` FOREIGN KEY (`current_class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_promotions_current_section_id_foreign` FOREIGN KEY (`current_section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_promotions_current_session_id_foreign` FOREIGN KEY (`current_session_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_promotions_previous_class_id_foreign` FOREIGN KEY (`previous_class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_promotions_previous_section_id_foreign` FOREIGN KEY (`previous_section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_promotions_previous_session_id_foreign` FOREIGN KEY (`previous_session_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_promotions_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_promotions_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_registration_fields`;
CREATE TABLE `sm_student_registration_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `field_name` varchar(191) DEFAULT NULL,
  `label_name` varchar(191) DEFAULT NULL,
  `active_status` tinyint(4) DEFAULT 1,
  `is_required` tinyint(4) DEFAULT 0,
  `student_edit` tinyint(4) DEFAULT 0,
  `parent_edit` tinyint(4) DEFAULT 0,
  `staff_edit` tinyint(4) DEFAULT 0,
  `type` tinyint(4) DEFAULT NULL COMMENT '1=student,2=staff',
  `required_type` tinyint(4) DEFAULT NULL COMMENT '1=switch on,2=off',
  `position` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_student_registration_fields_school_id_foreign` (`school_id`),
  KEY `sm_student_registration_fields_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_student_registration_fields_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_student_registration_fields_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_take_online_exams`;
CREATE TABLE `sm_student_take_online_exams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0=Not Yet, 1 = alreday submitted, 2 = got marks',
  `student_done` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0=Not Yet, 1 = complete',
  `total_marks` int(11) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `online_exam_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `record_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sm_student_take_online_exams_student_id_foreign` (`student_id`),
  KEY `sm_student_take_online_exams_online_exam_id_foreign` (`online_exam_id`),
  KEY `sm_student_take_online_exams_school_id_foreign` (`school_id`),
  KEY `sm_student_take_online_exams_academic_id_foreign` (`academic_id`),
  KEY `sm_student_take_online_exams_record_id_foreign` (`record_id`),
  CONSTRAINT `sm_student_take_online_exams_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_take_online_exams_online_exam_id_foreign` FOREIGN KEY (`online_exam_id`) REFERENCES `sm_online_exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_take_online_exams_record_id_foreign` FOREIGN KEY (`record_id`) REFERENCES `student_records` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_take_online_exams_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_take_online_exams_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_take_online_exam_questions`;
CREATE TABLE `sm_student_take_online_exam_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `trueFalse` varchar(1) DEFAULT NULL COMMENT 'F = false, T = true ',
  `suitable_words` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `take_online_exam_id` int(10) unsigned DEFAULT NULL,
  `question_bank_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `t_on_ex_id` (`take_online_exam_id`),
  KEY `sm_student_take_online_exam_questions_question_bank_id_foreign` (`question_bank_id`),
  KEY `sm_student_take_online_exam_questions_school_id_foreign` (`school_id`),
  KEY `sm_student_take_online_exam_questions_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_student_take_online_exam_questions_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_take_online_exam_questions_question_bank_id_foreign` FOREIGN KEY (`question_bank_id`) REFERENCES `sm_question_banks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_take_online_exam_questions_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `t_on_ex_id` FOREIGN KEY (`take_online_exam_id`) REFERENCES `sm_student_take_online_exams` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_take_onln_ex_ques_options`;
CREATE TABLE `sm_student_take_onln_ex_ques_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL COMMENT '0 unchecked 1 checked',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `take_online_exam_question_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `t_on_ex_q_id` (`take_online_exam_question_id`),
  KEY `sm_student_take_onln_ex_ques_options_school_id_foreign` (`school_id`),
  KEY `sm_student_take_onln_ex_ques_options_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_student_take_onln_ex_ques_options_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_take_onln_ex_ques_options_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `t_on_ex_q_id` FOREIGN KEY (`take_online_exam_question_id`) REFERENCES `sm_student_take_online_exam_questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_student_timelines`;
CREATE TABLE `sm_student_timelines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `staff_student_id` int(11) NOT NULL,
  `title` varchar(191) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `file` varchar(191) DEFAULT NULL,
  `type` varchar(191) DEFAULT NULL COMMENT 'stu=student,stf=staff',
  `visible_to_student` int(11) NOT NULL DEFAULT 0 COMMENT '0 = no, 1 = yes',
  `active_status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_student_timelines_school_id_foreign` (`school_id`),
  KEY `sm_student_timelines_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_student_timelines_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_student_timelines_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sm_student_timelines` (`id`, `staff_student_id`, `title`, `date`, `description`, `file`, `type`, `visible_to_student`, `active_status`, `created_at`, `updated_at`, `created_by`, `updated_by`, `school_id`, `academic_id`) VALUES
(2,	2,	'Exam',	'2023-11-26',	'Some Documen',	'public/uploads/student/timeline/stu-02a7517cc28627d01c06932a098de1cd.png',	'stu',	0,	1,	'2023-12-10 14:07:10',	'2023-12-10 14:07:10',	1,	1,	1,	4);

DROP TABLE IF EXISTS `sm_styles`;
CREATE TABLE `sm_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `style_name` varchar(255) DEFAULT NULL,
  `path_main_style` varchar(255) DEFAULT NULL,
  `path_infix_style` varchar(255) DEFAULT NULL,
  `primary_color` varchar(255) DEFAULT NULL,
  `primary_color2` varchar(255) DEFAULT NULL,
  `title_color` varchar(255) DEFAULT NULL,
  `text_color` varchar(255) DEFAULT NULL,
  `white` varchar(255) DEFAULT NULL,
  `black` varchar(255) DEFAULT NULL,
  `sidebar_bg` varchar(255) DEFAULT NULL,
  `barchart1` varchar(255) DEFAULT NULL,
  `barchart2` varchar(255) DEFAULT NULL,
  `barcharttextcolor` varchar(255) DEFAULT NULL,
  `barcharttextfamily` varchar(255) DEFAULT NULL,
  `areachartlinecolor1` varchar(255) DEFAULT NULL,
  `areachartlinecolor2` varchar(255) DEFAULT NULL,
  `dashboardbackground` varchar(255) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `is_default` tinyint(4) NOT NULL DEFAULT 0 COMMENT 'if 1 then yes, if 0 then no',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_styles_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_styles_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_subjects`;
CREATE TABLE `sm_subjects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(255) NOT NULL,
  `subject_code` varchar(255) DEFAULT NULL,
  `subject_type` enum('T','P') NOT NULL COMMENT 'T=Theory, P=Practical',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_subjects_school_id_foreign` (`school_id`),
  KEY `sm_subjects_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_subjects_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_subjects_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_subject_attendances`;
CREATE TABLE `sm_subject_attendances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attendance_type` varchar(10) DEFAULT NULL COMMENT 'Present: P Late: L Absent: A Holiday: H Half Day: F',
  `notes` varchar(500) DEFAULT NULL,
  `attendance_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `student_record_id` bigint(20) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `notify` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `sm_subject_attendances_subject_id_foreign` (`subject_id`),
  KEY `sm_subject_attendances_student_id_foreign` (`student_id`),
  KEY `sm_subject_attendances_school_id_foreign` (`school_id`),
  KEY `sm_subject_attendances_academic_id_foreign` (`academic_id`),
  KEY `sm_subject_attendances_student_record_id_foreign` (`student_record_id`),
  KEY `sm_subject_attendances_class_id_foreign` (`class_id`),
  KEY `sm_subject_attendances_section_id_foreign` (`section_id`),
  CONSTRAINT `sm_subject_attendances_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_subject_attendances_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_subject_attendances_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_subject_attendances_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_subject_attendances_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_subject_attendances_student_record_id_foreign` FOREIGN KEY (`student_record_id`) REFERENCES `student_records` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_subject_attendances_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `sm_subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_suppliers`;
CREATE TABLE `sm_suppliers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) DEFAULT NULL,
  `company_address` varchar(500) DEFAULT NULL,
  `contact_person_name` varchar(191) DEFAULT NULL,
  `contact_person_mobile` varchar(191) DEFAULT NULL,
  `contact_person_email` varchar(100) DEFAULT NULL,
  `cotact_person_address` varchar(500) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_suppliers_school_id_foreign` (`school_id`),
  KEY `sm_suppliers_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_suppliers_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_suppliers_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_system_versions`;
CREATE TABLE `sm_system_versions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `features` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_teacher_upload_contents`;
CREATE TABLE `sm_teacher_upload_contents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_title` varchar(200) DEFAULT NULL,
  `content_type` varchar(191) DEFAULT NULL COMMENT 'as assignment, st study material, sy sullabus, ot others download',
  `available_for_admin` int(11) NOT NULL DEFAULT 0,
  `available_for_all_classes` int(11) NOT NULL DEFAULT 0,
  `upload_date` date DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `source_url` varchar(191) DEFAULT NULL,
  `upload_file` varchar(200) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `class` int(10) unsigned DEFAULT NULL,
  `section` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_teacher_upload_contents_class_foreign` (`class`),
  KEY `sm_teacher_upload_contents_school_id_foreign` (`school_id`),
  KEY `sm_teacher_upload_contents_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_teacher_upload_contents_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_teacher_upload_contents_class_foreign` FOREIGN KEY (`class`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_teacher_upload_contents_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_temporary_meritlists`;
CREATE TABLE `sm_temporary_meritlists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `iid` varchar(250) DEFAULT NULL,
  `student_id` varchar(250) DEFAULT NULL,
  `merit_order` double(8,2) DEFAULT NULL,
  `student_name` varchar(250) DEFAULT NULL,
  `admission_no` varchar(250) DEFAULT NULL,
  `subjects_id_string` varchar(250) DEFAULT NULL,
  `subjects_string` varchar(250) DEFAULT NULL,
  `marks_string` varchar(250) DEFAULT NULL,
  `total_marks` double(8,2) DEFAULT NULL,
  `average_mark` double(20,2) DEFAULT NULL,
  `gpa_point` double(20,2) DEFAULT NULL,
  `result` varchar(250) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `exam_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_temporary_meritlists_exam_id_foreign` (`exam_id`),
  KEY `sm_temporary_meritlists_class_id_foreign` (`class_id`),
  KEY `sm_temporary_meritlists_section_id_foreign` (`section_id`),
  KEY `sm_temporary_meritlists_school_id_foreign` (`school_id`),
  KEY `sm_temporary_meritlists_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_temporary_meritlists_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_temporary_meritlists_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_temporary_meritlists_exam_id_foreign` FOREIGN KEY (`exam_id`) REFERENCES `sm_exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_temporary_meritlists_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_temporary_meritlists_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_testimonials`;
CREATE TABLE `sm_testimonials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `designation` varchar(191) NOT NULL,
  `institution_name` varchar(191) NOT NULL,
  `image` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_testimonials_school_id_foreign` (`school_id`),
  CONSTRAINT `sm_testimonials_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_time_zones`;
CREATE TABLE `sm_time_zones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) DEFAULT NULL,
  `time_zone` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_to_dos`;
CREATE TABLE `sm_to_dos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `todo_title` varchar(191) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `complete_status` varchar(191) DEFAULT 'P' COMMENT 'C for complete, N for not Complete, P Pending',
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_to_dos_school_id_foreign` (`school_id`),
  KEY `sm_to_dos_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_to_dos_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_to_dos_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_upload_contents`;
CREATE TABLE `sm_upload_contents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_title` varchar(200) DEFAULT NULL,
  `content_type` int(11) DEFAULT NULL,
  `available_for_role` int(11) DEFAULT NULL,
  `available_for_class` int(11) DEFAULT NULL,
  `available_for_section` int(11) DEFAULT NULL,
  `upload_date` date DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `upload_file` varchar(200) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_upload_contents_school_id_foreign` (`school_id`),
  KEY `sm_upload_contents_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_upload_contents_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_upload_contents_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_upload_homework_contents`;
CREATE TABLE `sm_upload_homework_contents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(10) unsigned DEFAULT 1,
  `homework_id` int(10) unsigned DEFAULT 1,
  `description` text DEFAULT NULL,
  `file` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_upload_homework_contents_student_id_foreign` (`student_id`),
  KEY `sm_upload_homework_contents_homework_id_foreign` (`homework_id`),
  KEY `sm_upload_homework_contents_school_id_foreign` (`school_id`),
  KEY `sm_upload_homework_contents_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_upload_homework_contents_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_upload_homework_contents_homework_id_foreign` FOREIGN KEY (`homework_id`) REFERENCES `sm_homeworks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_upload_homework_contents_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_upload_homework_contents_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_user_logs`;
CREATE TABLE `sm_user_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(191) DEFAULT NULL,
  `user_agent` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_user_logs_user_id_foreign` (`user_id`),
  KEY `sm_user_logs_role_id_foreign` (`role_id`),
  KEY `sm_user_logs_school_id_foreign` (`school_id`),
  KEY `sm_user_logs_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_user_logs_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_user_logs_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `infix_roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_user_logs_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_user_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_vehicles`;
CREATE TABLE `sm_vehicles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehicle_no` varchar(255) NOT NULL,
  `vehicle_model` varchar(255) NOT NULL,
  `made_year` int(11) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `driver_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_vehicles_school_id_foreign` (`school_id`),
  KEY `sm_vehicles_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_vehicles_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_vehicles_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_visitors`;
CREATE TABLE `sm_visitors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `visitor_id` varchar(255) DEFAULT NULL,
  `no_of_person` int(11) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `in_time` varchar(255) DEFAULT NULL,
  `out_time` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_visitors_school_id_foreign` (`school_id`),
  KEY `sm_visitors_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_visitors_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sm_visitors_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sm_weekends`;
CREATE TABLE `sm_weekends` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `is_weekend` int(11) DEFAULT NULL,
  `active_status` int(11) NOT NULL DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `created_at` varchar(191) DEFAULT NULL,
  `updated_at` varchar(191) DEFAULT NULL,
  `academic_id` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sm_weekends_school_id_foreign` (`school_id`),
  KEY `sm_weekends_academic_id_foreign` (`academic_id`),
  CONSTRAINT `sm_weekends_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sm_weekends_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `student_academic_histories`;
CREATE TABLE `student_academic_histories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `active_status` tinyint(1) NOT NULL DEFAULT 1,
  `occurance_date` date NOT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_academic_histories_student_id_foreign` (`student_id`),
  KEY `student_academic_histories_school_id_foreign` (`school_id`),
  KEY `student_academic_histories_academic_id_foreign` (`academic_id`),
  CONSTRAINT `student_academic_histories_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_academic_histories_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_academic_histories_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `student_attendance_bulks`;
CREATE TABLE `student_attendance_bulks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attendance_date` varchar(191) DEFAULT NULL,
  `attendance_type` varchar(191) DEFAULT NULL,
  `note` varchar(191) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `student_bulk_temporaries`;
CREATE TABLE `student_bulk_temporaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admission_number` varchar(191) DEFAULT NULL,
  `roll_no` varchar(191) DEFAULT NULL,
  `first_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `date_of_birth` varchar(191) DEFAULT NULL,
  `religion` varchar(191) DEFAULT NULL,
  `gender` varchar(191) DEFAULT NULL,
  `caste` varchar(191) DEFAULT NULL,
  `mobile` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `admission_date` varchar(191) DEFAULT NULL,
  `blood_group` varchar(191) DEFAULT NULL,
  `height` varchar(191) DEFAULT NULL,
  `weight` varchar(191) DEFAULT NULL,
  `father_name` varchar(191) DEFAULT NULL,
  `father_phone` varchar(191) DEFAULT NULL,
  `father_occupation` varchar(191) DEFAULT NULL,
  `mother_name` varchar(191) DEFAULT NULL,
  `mother_phone` varchar(191) DEFAULT NULL,
  `mother_occupation` varchar(191) DEFAULT NULL,
  `guardian_name` varchar(191) DEFAULT NULL,
  `guardian_relation` varchar(191) DEFAULT NULL,
  `guardian_email` varchar(191) DEFAULT NULL,
  `guardian_phone` varchar(191) DEFAULT NULL,
  `guardian_occupation` varchar(191) DEFAULT NULL,
  `guardian_address` varchar(191) DEFAULT NULL,
  `current_address` varchar(191) DEFAULT NULL,
  `permanent_address` varchar(191) DEFAULT NULL,
  `bank_account_no` varchar(191) DEFAULT NULL,
  `bank_name` varchar(191) DEFAULT NULL,
  `national_identification_no` varchar(191) DEFAULT NULL,
  `local_identification_no` varchar(191) DEFAULT NULL,
  `previous_school_details` varchar(191) DEFAULT NULL,
  `note` varchar(191) DEFAULT NULL,
  `user_id` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `student_records`;
CREATE TABLE `student_records` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `roll_no` varchar(191) DEFAULT NULL,
  `is_promote` tinyint(1) DEFAULT 0,
  `is_default` tinyint(4) DEFAULT 0,
  `session_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned NOT NULL DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_records_class_id_foreign` (`class_id`),
  KEY `student_records_section_id_foreign` (`section_id`),
  KEY `student_records_session_id_foreign` (`session_id`),
  KEY `student_records_school_id_foreign` (`school_id`),
  KEY `student_records_academic_id_foreign` (`academic_id`),
  KEY `student_records_student_id_foreign` (`student_id`),
  CONSTRAINT `student_records_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_records_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `sm_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_records_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_records_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sm_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_records_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_records_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `sm_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `telescope_entries`;
CREATE TABLE `telescope_entries` (
  `sequence` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `batch_id` char(36) NOT NULL,
  `family_hash` varchar(191) DEFAULT NULL,
  `should_display_on_index` tinyint(1) NOT NULL DEFAULT 1,
  `type` varchar(20) NOT NULL,
  `content` longtext NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`sequence`),
  UNIQUE KEY `telescope_entries_uuid_unique` (`uuid`),
  KEY `telescope_entries_batch_id_index` (`batch_id`),
  KEY `telescope_entries_family_hash_index` (`family_hash`),
  KEY `telescope_entries_created_at_index` (`created_at`),
  KEY `telescope_entries_type_should_display_on_index_index` (`type`,`should_display_on_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `telescope_entries_tags`;
CREATE TABLE `telescope_entries_tags` (
  `entry_uuid` char(36) NOT NULL,
  `tag` varchar(191) NOT NULL,
  KEY `telescope_entries_tags_entry_uuid_tag_index` (`entry_uuid`,`tag`),
  KEY `telescope_entries_tags_tag_index` (`tag`),
  CONSTRAINT `telescope_entries_tags_entry_uuid_foreign` FOREIGN KEY (`entry_uuid`) REFERENCES `telescope_entries` (`uuid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `telescope_monitoring`;
CREATE TABLE `telescope_monitoring` (
  `tag` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `transcations`;
CREATE TABLE `transcations` (
  `id` int(11) NOT NULL,
  `title` text DEFAULT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'debit',
  `payment_method` varchar(20) DEFAULT NULL,
  `reference` varchar(20) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `morphable_id` bigint(20) unsigned DEFAULT NULL,
  `morphable_type` varchar(191) DEFAULT NULL,
  `amount` bigint(20) NOT NULL DEFAULT 0,
  `transaction_date` date DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(11) NOT NULL DEFAULT 1,
  `academic_id` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `transcations_user_id_foreign` (`user_id`),
  CONSTRAINT `transcations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(192) DEFAULT NULL,
  `username` varchar(192) DEFAULT NULL,
  `email` varchar(192) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `usertype` varchar(210) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `random_code` text DEFAULT NULL,
  `notificationToken` text DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `language` varchar(191) DEFAULT 'en',
  `style_id` int(11) DEFAULT 1,
  `rtl_ltl` int(11) DEFAULT 2,
  `selected_session` int(11) DEFAULT 1,
  `created_by` int(11) DEFAULT 1,
  `updated_by` int(11) DEFAULT 1,
  `access_status` int(11) DEFAULT 1,
  `school_id` int(10) unsigned DEFAULT 1,
  `role_id` int(10) unsigned DEFAULT NULL,
  `is_administrator` enum('yes','no') NOT NULL DEFAULT 'no',
  `is_registered` tinyint(4) NOT NULL DEFAULT 0,
  `device_token` text DEFAULT NULL,
  `stripe_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `card_brand` varchar(191) DEFAULT NULL,
  `card_last_four` varchar(4) DEFAULT NULL,
  `verified` varchar(191) DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `wallet_balance` double(8,2) NOT NULL DEFAULT 0.00,
  `phone_number` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_school_id_foreign` (`school_id`),
  KEY `users_role_id_foreign` (`role_id`),
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `infix_roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `user_menus`;
CREATE TABLE `user_menus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1,
  `role_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `school_id` int(10) unsigned DEFAULT 1,
  `academic_id` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_menus_role_id_foreign` (`role_id`),
  KEY `user_menus_user_id_foreign` (`user_id`),
  KEY `user_menus_school_id_foreign` (`school_id`),
  KEY `user_menus_academic_id_foreign` (`academic_id`),
  CONSTRAINT `user_menus_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `sm_academic_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_menus_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `infix_roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_menus_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `sm_schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_menus_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `wallet_transactions`;
CREATE TABLE `wallet_transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `amount` double(8,2) DEFAULT NULL,
  `payment_method` varchar(191) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `note` varchar(191) DEFAULT NULL,
  `type` varchar(191) DEFAULT NULL COMMENT 'diposit, refund, expense, fees_refund',
  `file` text DEFAULT NULL,
  `reject_note` text DEFAULT NULL,
  `expense` double(8,2) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'pending' COMMENT 'pending, approve, reject',
  `created_by` int(11) DEFAULT NULL,
  `academic_id` int(11) NOT NULL DEFAULT 1,
  `school_id` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wallet_transactions_user_id_foreign` (`user_id`),
  CONSTRAINT `wallet_transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- 2023-12-10 13:17:25
